## Lec: セクションの概要------

#slide1-5

## Lec: イントロダクション-------

#slide 6-12

## Lec: 状況設定--------

#slide 13-20

## Lec: Rで単純集計:データの作成(sld:21)-------

# それではRで集計を行っていきましょう。
# スライドでお示しした通り、集計とは、
# ベクトル（数字や文字列、因子などの要素）
# の特徴を何かしらの代表的な値にまとめる
# ことになります
# 
# Rでこれを実施するためには、やりたい集計に
# 応じた関数を知っておく必要があります
# とりあえず、
# 
library(tidyverse)

dat <- tibble(
  num = c(1  ,2  ,3  ,4  ,5  ,6  ,7  ,8  ,9  ,10),
  fac2 =c("a","b","a","b","a","b","a","b","a","b") %>% as.factor(),
  fac3 =c("A","B","C","A","B","C","A","B","C","A") %>% as.factor()
)

dat
# こんな感じのtibbleを集計していくことを考えましょう
# 　numは数字ベクトル、
# 　fac2はレベルが二つの因子ベクトル、
# 　fac3はレベルが3つの因子ベクトル
# となります。

# ちなみに、繰り返しを簡単にできるrepという関数を
# 利利すると

rep( c("a","b"), 4)

# という感じで、最初に与えた要素、次に与えた数字の数
# だけくりかえしたベクトルを返してくれるので、
# 上のdatは、

dat <- tibble(
  num = 1:10,
  fac2 = rep(c("a","b"), 5),
  fac3 = rep(c("A","B","C"), 4)[1:10]
)

dat
#とも書けます。
#fac3で[1:10]としているのは

tibble(num  = 1:3, 
       test = c("a","b","c","a","b","c"))

# このように、tibble内では、すべて同じ長さの
# 要素を与えないとエラーが生じるので、

tibble(num  = 1:3, 
       test = c("a","b","c","a","b","c")[1:3] )

#ようそをnumの数と同じだけにするためのものです。
#repを使うと与えた要素の長さの倍数の長さにしか
#ならないので、この[]は地味に大切です。


#100行で同様のパターンのものを作りたければ

dat <- tibble(
  num = 1:100,
  fac2 = rep(c("a","b"), 50),
  fac3 = rep(c("A","B","C"), 100)[1:100] 
)

dat
#(本当はfac3繰り返し回数は34が最適ですが、
#計算するのが面倒なので全部100としています)
#
#ですし、X行のものを作る関数にしたければ、

genXrow <- function(X){
  tibble(
    num = 1:X,
    fac2 = rep(c("a","b")    , X)[1:X],
    fac3 = rep(c("A","B","C"), X)[1:X]
  )
}

dat <- genXrow(11)
dat

genXrow(10000)

# となります

# 余談でした。
# こういう風に、データを自分で作れるようになると
# 色々な関数や統計的なことを勉強する際に
# 自分で仕組みがわかっているデータを作成できるので
# おすすめです。
 
# それでは、次に、集計用の関数の解説を
# おこなっていきましょう

## Lec: Rで単純集計:数値の集計(sld:22)-------

#ここでは、ベクトルを与えると、
#集計した数値を返してくれる関数をご紹介いたします。

#まずは　「ベクトルに含まれる要素の個数」　です。

dat$num %>% length()

# これは簡単ですね。ベクトルの要素の個数が
# 帰ってきています。


#「和」

dat$num %>% sum()

# はい。これも単純に全部足し合わせただけです

#「算術平均」は

dat$num %>% mean()

#で計算できます
#。
#mean()をつかわないで計算するなら

sum(dat$num)/length(dat$num)

#と書いても計算可能です。

#　ここまでかいてきて、毎回dat$と書くのが面倒に
#　感じませんか？
#　
#　次の動画ではよりシンプルにこれらの演算をできる
#　書き方について解説していきます。

## Lec: Rで単純集計:シンプルな書き方での演算(attach)(sld:23)---------

# 前の動画では、基本である、個数、和、平均の
# 関数について説明しました。
# 
# ただ、一般的にtibbleなどからベクトルを取り出す
# $記号を利用したスクリプトは、
#    * 書くのにタイプ量が増える、
#    * tibbleの名前が長いと可読性が落ちる
# というところで、個人的にはお勧めできません。

# ですので、この動画では$サインをなるべく使わずに書く
# 方法についてご説明いたします。

# 方法1：`attach`を利用する方法

#一つ前の動画では、平均を求めるのに、
sum(dat$num)/length(dat$num)
#と記載していました。

#ただ、dat$と何回も打つのは面倒なので、
#できれば、次のようにnumとだけ打つことで
#ベクトルを呼び出せると便利です。

sum(num)/length(num) #エラーですね

#Environmentペーンの内容を少し覚えておいてください。

attach(dat) #とすると、ここ以降、dat$とかかなくてもOK

sum(num)/length(num)
num
fac2
fac3

detach(dat) #これでattach効果が消える
sum(dat$num)/length(dat$num)
sum(num)/length(num)　#エラー！

# 簡単ですね？
# ただ、detachを忘れたりするとエラーの原因になったり
# 思わぬ動作を引き起こすケースがあります。
# 具体的には。。

num <- 1000 #numという変数を使いたいので作成

#100行くらいのスクリプト

attach(dat) #fac2を利用したい

mean(num) #dat$numの平均を求めたつもり

#本当に求めたかったのは
mean(dat$num)

detach(dat)

#いかがでしょうか？
#このようなエラーが生じる可能性があるため、
#できればattach、detachは使わないようにしています

#ただし、ネットで検索した場合によく使われる関数
#でもあるのでここで紹介しました。

#次の動画では、attach, detachを使わないで計算する
#方法を解説いたします。

## Lec: Rで単純集計:シンプルな書き方での演算(dplyr::summarise)(sld:24)====================

# 方法2: DplyrのSummarise関数

# 実はDplyrには、attachと似たように利用できる
# `summarise`関数というものがあります。

# 単純集計やグループ集計を行う場合に
# 必須の関数になるため、単独での動きを
# しっかりと理解しておきましょう。

dat %>% 
  summarise(
    kosu  = length(num),
    mean1 = sum(num)/length(num),
    mean2 = mean(num)
  )

#だいぶattachと挙動が違いますがじっくりと
#みてみましょう

#datというデータを%>%でsummariseに与えてあげると、
#summariseの中では列名を書くだけで
#そのベクトルを利用することができます

#summarieの中で、
#　<新しい列名>=<ベクトル演算>
#とすることで、その列名にベクトルの演算結果が
#でてきます。


length(dat$num)
sum(dat$num)/length(dat$num)
mean(dat$num)

#これらの結果と、

dat %>% 
  summarise(
    kosu  = length(num),
    mean1 = sum(num)/length(num),
    mean2 = mean(num)
  )

#この動作、同じ結果ですね?
#このスクリプトの動作、腹落ちしましたか？

#この書き方の利点は、numという名前の変数が
#グローバル環境にあったとしても、問題なく
#意図した動作をしてくれるというところにあります。
#
#Environmentペーンを確認いただきたいのですが、
#ここまでのsummarise関数の実行時に、numという
#変数が存在している状態でした。
#しかし、それには影響を受けずに、与えられた
#データ/tibbleの列名がついたベクトルを
#取り出すことができています。
#この特徴があるため、attachを使うよりも思わぬエラーが
#回避できると思います。

#また、summarise関数の中でだけ動作する
#特別な関数もあるので次の動画ではその説明を行います。

## Lec: Rで単純集計:summariseの中で動く特別な関数(sld:25)-----------

?summarise

#の中の、Useful functionsというところを
#みていただくと、いくつか関数が紹介されています

#この中で、n()という関数だけは、
#dplyrのsummarise, mutate, filter等の中で
#だけしか使えない特別な関数となっています。

#その動作は、summarise,mutate,filterに与えられた
#データの列数を取得するというものになります。

#試しに、
n()
#単独で呼び出しても、dplyr verbsの中でしか使えません
#と怒られます。
#しかし、

dat %>% 
  summarise(
    number1 = n(),
    number2 = length(num)
  )

nrow(dat)

#いかがでしょう？
#n()を利用することでこれまでlength(列名)と
#していたものをだいぶ簡略化できましたね？
#
#データ加工では割合の計算や、統計的な計算でも頻用する
#関数になるのでここで是非理解しておいてください。

#次の動画では、スライドでお示しした、ケーキの
#購入データを例にして、データの単純集計を
#行ってみましょう。

## Lec: Rで単純集計:全体集計の課題(tidyverse)(sld:26)--------

#まずは、スライドで表示していたデータを作成しましょう

id <- 1:15
age <- c(30,40,65,34,86,43,64,26,87,45,76,24,97,45,34)
gender <- c("m","m","f","f","f","m","m","f","f","m","f","f","m","m","m")
isx <- c(F,T,F,F,T,T,T,F,T,F,T,F,F,F,T)

dat <- tibble(id     = id, 
              age    = age, 
              gender = gender, 
              isx    = isx   )

#こんな感じのデータでしたね?
dat

#では、プチ課題ですが、
#　年齢の平均値
#　性別(m)の割合
#　をsummarise関数を利用して作成してみてください。






#できましたか?男性の割合が
#少しむずかしいかもしれません。


dat2 <- dat %>% 
  summarise(age_mean = mean(age),
            gender_male_p  = sum(gender=="m")/n() )


# いかがでしょうか？
# 年齢の平均、性別の個数と割合の計算を
# ここでは行っていますが、スクリプトの動作、
# イメージできますか？

dat2

#このdat2をスライドでお示しした形に変換してみましよう。

#この処理は、Section5のpivot_xxx関数を利用すればできます
#ビデオをとめてやってみてください。

#できましたか?








#pivot_longerだけを利用するのであれば、
dat2 %>% 
  pivot_longer(everything())

#これだけでもOKです。ただ、スライドのように日本語
#で書くのであれば

dat2 %>% 
  
  mutate(
    `年齢(平均)` = age_mean,
    `性別:男性(%)` = 100*gender_male_p
  ) %>%
  
  select(!c(age_mean, gender_male_p)) %>% 
  
  pivot_longer(everything(),
               names_to = " ",
               values_to = "全体")

#どうでしょうか？集計できましたね？

#次以降の動画では、この変換について
#1行ずつ解説していきます。

## Lec: Rで単純集計:全体集計の実践(tidyverse)-解説(sld:27)-----------

#それでは解説していきます。
#まず、データを準備します
id <- 1:15
age <- c(30,40,65,34,86,43,64,26,87,45,76,24,97,45,34)
gender <- c("m","m","f","f","f","m","m","f","f","m","f","f","m","m","m")
isx <- c(F,T,F,F,T,T,T,F,T,F,T,F,F,F,T)

#tibble関数を利用してベクトルを一つの
#テーブルとしてまとめます
hyou <- tibble(id     = id, 
               age    = age, 
               gender = gender, 
               isx    = isx   ) %>% 
  
  #サマライズを利用してデータを集計します
  summarise(age_mean = mean(age),
            gender_male_p  = sum(gender=="m")/n() ) 



hyou <- hyou %>% 
  mutate(
    `年齢(平均)` = age_mean,
    `性別:男性(%)`  = 100*gender_male_p
  )

hyou

#ここでヨコ持ちのデータになっていますが、
#目的とする集計は終わっています。

#あとは、縦方向のデータに変換すればよいので、
#必要な列だけ残して、変換しましょう。

hyou <- hyou %>% 
  select(!c(age_mean, gender_male_p)) %>% 
  pivot_longer(everything(),
               names_to = " ",
               values_to = "全体")

hyou

#完成です。

hyou

#いかがでしょうか？
#今回は1ステップずつわけて関数の処理を実行しましたが
#実際は 

hyou <- tibble(id  = id, 
               age = age, 
               gender = gender,
               isx    = isx   ) %>% 
  
  summarise(age_mean = mean(age),
            gender_male_p  = 100*sum(gender=="m")/n() ) %>% 
  mutate(
    `年齢(平均)` = age_mean,
    `性別:男性(%)`  = gender_male_p
  ) %>%
  select(!c(age_mean, gender_male_p)) %>% 
  pivot_longer(everything(),
               names_to = " ",
               values_to = "全体") 
  

hyou

#こんな感じで処理を書くと目的の集計ができあがりました！
#
#いかでしょうか?
#処理の内容理解できましたか?
#
#ここで上の内容を応用してもう少し複雑な集計を
#やってみましょう。

dat <- tibble(id     = id, 
              age    = age, 
              gender = gender, 
              isx    = isx   )

dat

#のデータを加工して、

# |年齢:平均(最小-最大)| XX.XX(XX-XX)|
# |性別:男性 人数(%)   | XX(XX.X%)   |

#というような形に加工しましょう。
#もしご自身でできそうな場合は、とりくんでみてください。
#
#最小を求める関数は、min
#最大を求める関数は、max
#文字列を結合するには、stringr::str_c関数
#を利用します。


## Lec: Rで単純集計:全体集計の実践(tidyverse)-応用1-format(sld:28)-----------

#それでは、

#|年齢:平均(最小-最大)| XX.XX(XX-XX)|
#|性別:男性 人数(%)   | XX(XX.X%)   |

#という形の結果を求めてみましょう。
#まずは集計です

dat %>% 
  summarise(
    age_mean = mean(age),
    age_min  = min(age),
    age_max  = max(age),
    gender_male_n = sum(gender=="m"),
    gender_male_p = 100*(gender_male_n/n())
  )

#できましたね?
#次に結果となる列を作成してみましょう。

dat %>% 
  summarise(
    age_mean = mean(age),
    age_min  = min(age),
    age_max  = max(age),
    gender_male_n = sum(gender=="m"),
    gender_male_p = 100*(gender_male_n/n())
  ) %>% 
  mutate(
    `年齢:平均(最小-最大)` = str_c(age_mean,"(",age_min,"-",age_max,")"),
    `性別:男性 人数(%)`    = str_c(gender_male_n,"(", gender_male_p,"%)")
  ) %>% 
  select(matches("^年齢|^性別"))

#ここでmatchesは正規表現で列名を指定することが、
#可能です
#ここまでの結果なにかがへんです。

#ここで、結果を文字列に変更して、str_c関数で文字列同士
#の結合をしているのですが、

x <- mean(dat$age)
y <- min(dat$age)
z <- max(dat$age)

x
y
z

str_c(x,"(",y,"-",z,")")

#このように、年齢の平均値の桁数がものすごく
#長い形で文字列に変更されてしまっています。
#これは、

as.character(x)

#で変換しても同じ様な問題が生じるので、
#「うまい形に変換」してあげる必要があります。

#この場合、利用するのは
#format関数が有名です。

format(1.234567,digits = 1)
format(1.234567,digits = 2)
format(1.234567,digits = 3)
format(1.234567,digits = 4)
format(1.234567,digits = 5)

#このようなかたちで、digitsで桁数を指定してあげると
#頭からの桁数を指定して、四捨五入をしたうえで文字に変換してくれます。
#ただしこれだと、小数点2桁に固定して表示したいような場合は、

format(2.345, digits=3)
format(234.567, digits=3)

#整数部分の桁数に影響を受けるため、うまくいきません。

#かならず小数点2桁で表示したい
#というケースでは、小数点
#を指定して四捨五入してくれる、round関数
#を併用するとうまくいきます。

round(  2.3454656456454456,2) 
round(234.5676456456456456,2) 

format(round(  2.3454656456454456,2) )
format(round(234.5676456456456456,2) )

#このように、round関数と組み合わせてあげると、
#うまくいきます。
#ただし、

format(round(2  ,2))
format(round(2.1,2))

#このように、「整数」の場合や小数の長さが
#目的の長さに足りない場合は
#小数点2桁を印字してくれないので、
#format の　nsmall引数を利用します。
format(1.0123, nsmall=2)
format(round(2  ,2), nsmall = 2)
format(round(2.1,2), nsmall = 2)

#これは「表示されないといけない」
#小数の桁数を指定してあげると、0で埋めてくれます。

#というわけで
str_c(x,"(",y,"-",z,")")

#は、
x2 <- format(round(x,2),nsmall=2)
y2 <- format(round(y,2),nsmall=2)
z2 <- format(round(z,2),nsmall=2)

str_c(x2,"(",y2,"-",z2,")")

#という形で表示できました。

#では、今の知識を利用して、
dat %>% 
  summarise(
    age_mean      = mean(age),
    age_min       = min(age),
    age_max       = max(age),
    gender_male_n = sum(gender=="m"),
    gender_male_p = 100*(gender_male_n/n())
  ) %>% 
  mutate(
    `年齢:平均(最小-最大)` = str_c(age_mean,"(",age_min,"-",age_max,")"),
    `性別:男性 人数(%)`    = str_c(gender_male_n,"(", gender_male_p,"%)")
  ) %>% 
  select(matches("^年齢|^性別"))

#の表示を良い感じにするのであれば、mutate部分で利用する
#変数の数字にformatと、roundを入れてあげればよいです。
#5個の変数全てに適応してあげましょう。

dat %>% 
  summarise(
    age_mean      = mean(age),
    age_min       = min(age),
    age_max       = max(age),
    gender_male_n = sum(gender=="m"),
    gender_male_p = 100*(gender_male_n/n())
  ) %>% 
  mutate(
    age_mean      = format(round(age_mean,2),nsmall=2),
    age_min       = format(round(age_min ,2),nsmall=2),
    age_max       = format(round(age_max ,2),nsmall=2),
    gender_male_p = format(round(gender_male_p,2),nsmall=2),
    gender_male_n = format(round(gender_male_n,2),nsmall=2)
  ) %>% 
  mutate(
    `年齢:平均(最小-最大)` = str_c(age_mean,"(",age_min,"-",age_max,")"),
    `性別:男性 人数(%)`    = str_c(gender_male_n,"(", gender_male_p,"%)")
  ) %>% 
  select(matches("^年齢|^性別"))

#はい。うまく表示できましたね?
#ただ、1回目のmutate部分で、format...の部分
#変数名を入れ替えて繰り返しているだけになっており、
#面倒ではありませんでしたか?
#次の動画で、このように「同じ操作を複数列に行う」
#ケースのもっと短い書き方をお伝えいたします。

## Lec: Rで単純集計:全体集計の実践(tidyverse)-応用2-across-----------

#slide 29-42

## Lec: Rで単純集計:全体集計の実践(tidyverse)-応用3-across(sld43)-----------

#それでは、スライドで解説したacross関数を、実際にRで実行してみます。

library(tidyverse)

test <- tibble(
  a1 = c(12,13,14),
  b1 = c(1,2,3),
  a2 = c(3.22345, 3.542352345, 4.4235235)
)

test

#こんなデータがあるとして、

#全部の列を100倍する:
test %>% mutate( across(.cols=everything(), .fns = ~{. * 100}) )

#どうでしょうか?mutate関数の中で、acrossを利用して、
#そのacrossのargumentsに、.colsはeverything()、　.fnsは
#~{}で無名関数を作成して、その中身として 「. * 100」
#が入れてある構造、理解できますか？

#この書き方、argumentの順番さえ間違えなければ。.colsや.fns
#を書く必要はないので、

test %>% 
  mutate(across( everything(), ~{.*100}))

#と書いてもOKです。
#では、.colsで列の選択がtidy-selectを利用できることを
#確認してみましょう。

test %>% 
  mutate(across(starts_with("a"), ~{.*100}))

#statrt_withで、ちゃんと、aで始まる列だけ100倍されていますね?
#他にも、

test %>% 
  mutate(across(c(a1,b1), ~{.*100}))

test %>% 
  mutate(across(!b1, ~{.*100}))

test %>% 
  mutate(across(ends_with("2"), ~{.*100}))

#等も、なにをしているかお判りでしょうか?

#それでは、次に、もともととりくんでいたデータの集計について、
id <- 1:15
age <- c(30,40,65,34,86,43,64,26,87,45,76,24,97,45,34)
gender <- c("m","m","f","f","f","m","m","f","f","m","f","f","m","m","m")
isx <- c(F,T,F,F,T,T,T,F,T,F,T,F,F,F,T)

tibble(id     = id, 
       age    = age, 
       gender = gender, 
       isx    = isx   ) %>% 
  summarise(
    age_mean = mean(age),
    age_min = min(age),
    age_max = max(age),
    gender_male_n = sum(gender=="m"),
    gender_male_p = 100*(gender_male_n/n())
  ) %>% 
  mutate(
    age_mean = format(round(age_mean,2),nsmall=2),
    age_min  = format(round(age_min ,2),nsmall=2),
    age_max  = format(round(age_max ,2),nsmall=2),
    gender_male_p = format(round(gender_male_p,2),nsmall=2),
    gender_male_n = format(round(gender_male_n,2),nsmall=2)
  ) %>% 
  mutate(
    `年齢:平均(最小-最大)` = str_c(age_mean,"(",age_min,"-",age_max,")"),
    `性別:男性 人数(%)` = str_c(gender_male_n,"(", gender_male_p,"%)")
  ) %>% 
  select(matches("^年齢|^性別")) %>% 
  pivot_longer(cols = everything(),names_to = " ", values_to = "合計")

# この処理、acrossを利用して、少し簡潔に書いてみてください？
# 動画をとめてとりくんでみてください。
# 
# 
# できましたか?
# こう書けます。

tibble(id     = id, 
       age    = age, 
       gender = gender, 
       isx    = isx   ) %>% 
  summarise(
    age_mean = mean(age),
    age_min = min(age),
    age_max = max(age),
    gender_male_n = sum(gender=="m"),
    gender_male_p = 100*(gender_male_n/n())
  ) %>% 
  mutate(
    across( everything(), ~{format(round(.,2),nsmall=2)})
  ) %>%  
  mutate(
    `年齢:平均(最小-最大)` = str_c(age_mean,"(",age_min,"-",age_max,")"),
    `性別:男性 人数(%)` = str_c(gender_male_n,"(", gender_male_p,"%)")
  ) %>% 
  select(matches("^年齢|^性別"))  %>% 
  pivot_longer(cols = everything(),names_to = " ", values_to = "合計")


#いかがでしょうか?

# mutate(
#   age_mean = format(round(age_mean,2),nsmall=2),
#   age_min  = format(round(age_min ,2),nsmall=2),
#   age_max  = format(round(age_max ,2),nsmall=2),
#   gender_male_p = format(round(gender_male_p,2),nsmall=2),
#   gender_male_n = format(round(gender_male_n,2),nsmall=2)
# )
  
#の部分が、

#mutate(
# across( everything(), ~{format(round(.,2),nsmall=2)})
# )

#たったこれだけになりました。
#特に列数が多い場合に、有効な方法になりますので、
#使えそうであれば、使ってみてください。

#以上、単純集計の話でした。
#次からは、いよいよ集団で集計する話に進んでいきます。

## Lec: Rで集団集計:イメージで理解する---------

#slide44-52

## Lec: Rで集団集計:group_by関数------------

#SLIDE 53-69

## Lec: Rで集団集計:group_byの効果の確認(sld70)----------------

#ひとつ前と二つ前の動画ではgroup_by関数についての 
#イメージを作るための解説を実施してきました。

#ここからは、group_by関数のR上での動きについて
#その動作を確認していきましょう。

#まず、改めて、スライドで解説したデータを生成します
id <- 1:15

age <- c(30,40,65,34,86,
         43,64,26,87,45,
         76,24,97,45,34)

gender <- c("f","m","f","f","f",
            "m","m","f","f","m",
            "f","f","m","m","m")

isx <- c(F,T,F,F,T,
         T,T,F,T,F,
         T,F,F,F,T)

dat <- tibble(id     = id    , age = age, 
              gender = gender, isx = isx)

#このデータを利用して、
#まずは、グループに分ける処理を行います。

dat %>% 
  group_by(isx)

#実行結果は特に普段と変わらなさそうですが、

#Groups:　isx[2]

#という表記がコンソール画面にでていることに
#気づきましたか？

#tible形式では、グループ化されたデータを印字すると
#このように、どのようなグループ分け
#(スライドでいう赤い線)
#が引かれているかを明記してくれます。

#では、group_by関数が本当に働いている
#のか、ちょっと実験してみましょう。
#次の二つのスクリプトの実行結果が
#どのように変わるか、予測できますか？

dat %>% 
  mutate(new = length(isx))

dat %>% 
  group_by(isx) %>% 
  mutate(new = length(isx))

#group_byを挟まない場合は、
#length(isx)は15個なので、
#
#newという新しい変数の中には
#15という数字が入っています。
#
#ところが、group_byを間にかませると、
#newは、isxの値がTRUEだと7、
#                FALSEだと8  という数字になっています

#このように、group_byを入れることで
#仮想の赤い線/データが仮に区切られている
#
#という状況が作り出されたことが確認できました。

#それでは、次の動画に進む前に、年齢、性別をisx毎に
#
# * 年齢は平均、最小、最大、
# * 性別は男性の数と全体に占める割合
#
#を計算するスクリプトを書いてみてください。

## Lec: Rで集団集計:group_byでの集計(sld71)----------------

#ひとつ前の動画での課題、やってみましたか？
#次のようなスクリプトができているば、こちらが
#意図していた通りとなります。

dat %>% 
  group_by(isx) %>% 
  summarise(
    age_mean = mean(age),
    age_min  = min(age),
    age_max  = max(age),
    gender_m_n  = sum(gender=="m"),
    gender_m_p  = 100*gender_m_n/n()
  )


#ところで、集団で「ない」集計のときに
#集計した結果を表示するスクリプトを
#再度記載してみます

res <- tibble(id     = id, 
              age    = age, 
              gender = gender, 
              isx    = isx   ) %>%
  
  summarise(age_mean = mean(age),
            age_min = min(age),
            age_max = max(age),
            gender_male_n  = sum(gender=="m"),
            gender_male_p  = 100*gender_male_n/n() ) %>% 
  
  mutate(across(everything(), ~{format(.,nsmall=1, digits=1)}))　%>% 
  
  mutate(
    `年齢(最小-最大)` = str_c(age_mean,"(",age_min,"-",age_max,")"),
    `性別:男性(%)`  = str_c(gender_male_n,"(",gender_male_p,")")
  ) %>%
  
  select(matches("^年齢|^性別")) %>% 
  
  pivot_longer(everything(),
               names_to = " ",
               values_to = "全体")
  
res

#これの、summariseの手前にgroup_by(isx)をいれて、
#select()以降を除去して実行してみましょう。
#また、across関数の部分では、isxはロジカル型の
#ままで残しておきたい(文字列に変更する必要がない)
#ので、.colsで省いておきます
#
res2 <- 
tibble(id     = id, 
       age    = age, 
       gender = gender, 
       isx    = isx   ) %>%
  group_by(isx) %>%  #これを足した
  summarise(age_mean = mean(age),
            age_min = min(age),
            age_max = max(age),
            gender_male_n  = sum(gender=="m"),
            gender_male_p  = 100*gender_male_n/n() ) %>% 
  mutate(
    across(
      .cols=!isx, #isxは変換しない。
      ~{format(.,nsmall=1, digits=1)}
    )
  )　%>% 
  mutate(
    `年齢(最小-最大)` = str_c(age_mean,"(",age_min,"-",age_max,")"),
    `性別:男性(%)`  = str_c(gender_male_n,"(",gender_male_p,")")
  ) 

View(res2)
#いかがでしょうか？isx毎に、
#最初に作った集計がうまくできていることが
#確認できますね？

#あとは、この結果をうまく最終的に表示したい

#|               | 購入あり | 購入なし|
#|年齢(最小-最大)|  ~~~~~~  | ~~~~~~~ |
#|性別:男性(%)   |  ~~~~~~  | ~~~~~~~ |

#こんな形に持っていくことができたら
#最初の目標である、グループ集計の完成です。

#できますか?今表示されているこの結果から、
#この表の形になるように動画をとめて実行してみてください。
#pivot_longerとpivot_widerを1回ずつ使うとその形にできます


#やってみましょう。
#まず必要な列のみに絞り込んでおきます。
res2 %>% 
  select(isx, matches("^年齢|^性別"))

#こんな感じですね。
#それで、pivot_longerで一度縦持ちデータに変換しましょう
res2 %>% 
  select(isx, matches("^年齢|^性別")) %>% 
  pivot_longer(cols=!isx,names_to="name",values_to="value")

#後は、このデータをisxを横方向に広げてあげるとよいので
res2 %>% 
  select(isx, matches("^年齢|^性別")) %>% 
  pivot_longer(cols=!isx,names_to="name",values_to="value") %>% 
  pivot_wider(id_cols=name, names_from=isx, values_from=value)

#良い感じですね?
#後は、名前を変更しつつ並び替えてみましょう
res2 %>% 
  select(isx, matches("^年齢|^性別")) %>% 
  pivot_longer(cols=!isx,names_to="name",values_to="value") %>% 
  pivot_wider(id_cols=name, names_from=isx, values_from=value) %>% 
  select(` ` = name, `購買あり`=`TRUE`, `購買なし`=`FALSE`)


#できあがりました!
#お疲れさまでした。
#ここまでで、dplyrのみを使って集計して、表を作成することに
#とりくんできました。
#
#group_by関数やacross関数の使い方を解説するため、
#「めんどうな方法」をあえてここではお示ししています。

#次の動画からは、group_by関数の使い方を
#実例をご提示しながら解説していきます。

## Lec: group_by関数の使い方の例-count(sld72)---------

#それでは、group_by関数の使い方について解説していきます。
#利用するデータは、
library(tidyverse)
{
  set.seed(12345)
  dat <- tibble(
    q1 = sample(letters[1:3],100,replace = TRUE),
    q2 = sample(letters[1:3],100,replace = TRUE),
    q3 = sample(letters[1:3],100,replace = TRUE),
    q4 = sample(letters[1:3],100,replace = TRUE),
    q5 = sample(letters[1:3],100,replace = TRUE)
  )
  write_excel_csv(dat,"data/practice_group_by.csv")  
}

dat <- read_csv("data/practice_group_by.csv")

#こんなデータです。
#まず例えば、q1変数での解答はそれぞれ何件あるかを確認する
#には、

dat %>% 
  group_by(q1) %>% 
  summarise(n = n())

#としてあげることで、q1でグループ化して
#summariseで数を数えることができました

#おなじように、q1とq2の変数の組み合わせが何件あるのか
#を確認するには、

ex2 <- dat %>% 
  group_by(q1,q2) %>% 
  summarise(n = n())

ex2
#このように、group_byに二つの変数を入れるとOKです。
#ただ、注意が必要なのは、Summariseをすると、groupの指定が
#「1段階解除される」という仕組みになっており、ex2データの
#グループは、q1のみとなっています。

#グループが残っていると、おもわぬ動作が生じることがあります
#例えば、

ex2 %>% select(!q1)

#と、ex2からq1変数を除去しようとしても、groupに利用されている
#変数は除去できず、もとにもどってしまいます。
#なので、グループ集計等、グループである必然性がないデータに
#ついては、

ex3 <- ex2 %>% ungroup()

ex3

#このように、ungroup()関数を用いてグループを解除しておくか、

dat %>% 
  group_by(q1,q2) %>% 
  summarise(n = n(), .groups="drop")

#このように.groups="drop"という設定をしておくと、自動的に
#グループ化が解除された形でデータが帰ってきます。
#
#注意：この.groups=dropという仕様は、この動画を作成時点で
#実験的な試みらしいので、将来的には動作が変更される
#可能性があります。
#
#なので、個人的にはungroup()で明示的にグループ解除
#を必要がなくなったら行う癖付けをしておくほうがよいよう
#に思っています。
#
#(1つの関数で色々な処理をするよりも、1関数、1処理で
#シンプルに書いておく方が分かりやすい気がします。)

#さて、ここまでの例では、組み合わせを含めて数を数える
#という方法を解説してきました

ex3

#ただ、実は、この処理をもっと簡単に書く方法がり、
dat %>% count(q1,q2)

#このように、count関数を利用しましよう。
?count
#をみても、ほぼ同じ処理であると書いてありますね。

#次にgroup_byとmutateを組み合わせてみましょう。

dat2 <- dat %>% 
  count(q1,q2)

dat2

#このように集計されたデータに対して、
#例えば、
#　q1=aの中で、q2=aが占める割合
#等を計算したいときに、

dat2 %>% 
  group_by(q1) %>% 
  mutate(nq1 = sum(n))

#このように書いてあげると、q1という集団毎の
#sum(n)の値を入れた列を新たに作成することができます。

dat2 %>% 
  #group_by(q1) %>% 
  mutate(nq1 = sum(n))

#このように,group_byがない場合は、単純にn列の全て
#の数字を足した値が繰り返してnq1列に挿入されますが、

dat2 %>% 
  group_by(q1) %>% 
  mutate(nq1 = sum(n))

#グループ化してあげると、q1のグループ毎に集計された
#値がnq1に含まれます。
#ここでも、group_byでデータに線が入って分割された
#別々の表で処理が行われているとイメージがあると、
#mutateの動作も理解できるのではないでしょうか?

#次の動画からはデータの処理でよく遭遇する「差の計算」について
#解説していきます

## Lec: 差の計算---------

#slide73-81

## Lec: group_byと差の計算-------

#slide82-92

## Lec: 差の計算のRでの実践(sld93)---------

#それでは、ここからは、lag、leadなどの
#関数の動作をRで見ていきましょう。

#まずは、スライドで紹介した関数の
#ベクトルに対する動作を改めて
#確認しておきます。

library(tidyverse)
vec <- c(1,2,3,4,5)

dplyr::lag(vec)
dplyr::lead(vec)
dplyr::first(vec)
dplyr::last(vec)
dplyr::nth(vec,3)

#これらの関数の動作、イメージ通り
#でしょうか。
#lagが後ろにずらし、
#leadが前にずらし
#firstが一番目の要素
#lastが最後の要素
#nthがn番目の要素を取り出す
#という関数になっています。

#tibbleの列に対しても実行してみましょう

dat <- tibble(
  a = c(1,2,3,4,5)
)

dat %>% 
  mutate(
    a_lag=lag(a),
    a_lead = lead(a),
    a_first = first(a),
    a_last = last(a),
    a_third = nth(a,3)
  )

#いかがでしょうか?
#スライドでの説明通りに動いていますね?

#group_byを入れてあげる場合も

dat <- tibble(
  id = c(1 ,1 ,1 ,1 ,2 ,2 ,2 ,2 ,3 ,3 ,3 ,3),
  v  = c(11,12,13,14,21,22,23,24,31,32,33,34) 
)

dat %>% 
  mutate(
    v_lag=lag(v),
    v_lead = lead(v),
    v_first = first(v),
    v_last = last(v)
  )
#こんな感じの結果が、

dat %>%
  group_by(id) %>% 
  mutate(
    v_lag=lag(v),
    v_lead = lead(v),
    v_first = first(v),
    v_last = last(v)
  )

#mutateだとこうなって、
#summariseだと、

dat %>%
  group_by(id) %>% 
  summarise(
    v_first = first(v),
    v_last = last(v),
    v_second = nth(v,2)
  )

#こうなりました。
#いかがでしょうか?
#ここでご紹介した関数を利用すれば、
#縦方向に時系列で保存されているデータ
#から、差や比等を抽出することできそうですね?
#
#次の動画では、これらの関数を利用した
#課題をお出しいたします。

#Lec: 差の計算の課題と解答(sld94)-----------------------

{
  library(tidyverse)
  set.seed(123456)
  dat <-  tibble(
    id = 1:30,
    tx = sample(c("E","F"),30,replace=TRUE),
    base = runif(30,12,40)
  ) %>% 
    mutate(val = map2(base,tx,~{
      init <- .
      diff <- if(.y=="E"){-2}else{1}
      end <- init + rnorm(1,diff,3)
      
      seq(init,end,length.out=10) +
        c(0,rnorm(8,0,1),0)
    }))
  
  dat <- dat %>% unnest(c(val)) %>% 
    select(id,tx,val)
  
  write_excel_csv(dat,"data/laglead.csv")
}#データ生成の関数

#それでは、出題します。
#1) data/laglead.csvというデータを
#読み込んでください。
#
#2)読み込んだデータは、idが
#個々人を表す数値で、valには、
#10回測定したBMIの数値が含まれています。
#この、測定から測定間の差を計算してください
#
#3)各々のid毎に、最終測定結果　-　初回測定結果の値をもとめて
#ください。
#
#4)Txという変数は、その人たちに運動(Exercise)か食事(Food)
#のどちらにとりくんだかの変数です。
#EとF、おのおのについて初回と最後の測定の体重の変化量を
#利用して
#　* p_weight: 体重が減少した人数の割合
#　* mean_weight: 体重の変化の平均値
#という変数でもとめてみてください。
#
#
#それでは、
#動画をとめて、とりくんでみてください。



#やってみましたか?
#答え合わせをしてみましょう。

#1) data/laglead.csvというデータを
#読み込んでください。

library(tidyverse)
dat <- read_csv("data/laglead.csv")

#2)読み込んだデータは、idが
#個々人を表す数値で、valには、
#10回測定したBMIの数値が含まれています。
#この、測定から測定間の差を計算してください

dat %>% 
  group_by(id) %>% 
  mutate(prev_val = lag(val)) %>% 
  mutate(diff_val = val - prev_val)

#これで、diff_valには前回から今回にかけて変化した量が
#保存されます。

#3)各々のid毎に、最終測定結果　-　初回測定結果の値をもとめて
#ください。

dat %>% 
  group_by(id) %>% 
  summarise(init = first(val),
            last = last(val)) %>% 
  mutate(l_f = last - init)

#4)Txという変数は、その人たちに運動(Exercise)か食事(Food)
#のどちらにとりくんだかの変数です。
#EとF、おのおのについて初回と最後の測定の体重の変化量を
#利用して
#　* p_weight: 体重が減少した人数の割合
#　* mean_weight: 体重の変化の平均値
#という変数でもとめてみてください。

dat %>% 
  group_by(tx,id) %>% 
  summarise(diff = last(val)- first(val)) %>% 
  summarise(
    p_weight = sum(diff < 0)/n(),
    mean_weight = mean(diff)
  )
#ということで、txがEの方がBMIが減っている人の
#割合も大きいし、数値の変化も平均的に2.29減っている
#ということがわかりました。
#(このデータは、架空のものです）
#
#いかがでしょうか?
#集計を利用してこのように、データの変数を加工すること、
#なんとなくイメージがついたでしょうか?
#次の動画では、ここで紹介した方法と組み合わせることが
#多い、時間のデータを取り扱う方法について簡単に説明して
#セクションを締めくくろうと思います。

## Lec:時間の型(sld95)-------------------------------
#
#それでは、本セクション最後の話題を説明していきましょう。
#時間の型についてです。
#
#時間をＲで扱う場合は、lubridateというpackageが
#tidyverseに含まれるものとして便利なので、本コース
#ではそれを利用して解説していきます。

#時間を表すデータには
#　日付型
#　時刻型
#　の二つがあります。
#　
#　これらの正体は、ただの数字なのですが、
#　ある日を基準として時間を表しています。
library(tidyverse)
library(lubridate)

#まず日付型からみていきます。
#日付型を作成するのは、as_date関数です。
#as_dateには、数字を入れることもできますし
pdate1 <- lubridate::as_date(0)

#文字列型を入れることもできます。
pdate2 <- lubridate::as_date("1970-1-1")

#この日付型ですが、
pdate1　#印字すると日付がでて
class(pdate1) #classをみるとDate型とでます
as.numeric(pdate1) #数字に戻すと、0で
as.character(pdate1) #文字列にすると、表示された日になります

#ちょっと因子型みたいですね。
#pdate2もおなじように
pdate2
class(pdate2)
as.numeric(pdate2)
as.character(pdate2)


#この日付型、0を日付に変換すると、1970-1-1でした。
#実は、日付型は、正体が数字で、1970年1月1日を起点として
#何日経過しているか（あるいは何日前か)というところで
#表示されています。
#なので、
#1970年1月1日を0日として、10000日目は、
as_date(10000)
#となります。 


#時刻がついたデータも同じ様に作成することができて、

t1 <- as_datetime(1)

t1
class(t1) # POSIXct POSIXt というクラスがついており
as.numeric(t1) #数字に変換すると1、
as.character(t1) #文字列に変換すると日付―時刻という形

#になります。
# 
# この関数も文字列型から日付時刻型に変換することが
# 可能で、

t2 <- as_datetime("2000-01-01 12:30:45")
t2
class(t2)
as.numeric(t2)
as.character(t2)

#こんな感じです。
#
#どうでしょうか?
#ただの数字が時刻や日付に変わっているの、
#すこし不思議に感じるかもしれませんが、
#これで、時間や時刻データを扱える基本が身に付きました。
#
#次は文字列を日付型や時刻型に変換する方法を少し詳しく
#みていきましょう。

## Lec: 文字列を日付・時刻型へ(sld96)------------
#
#この、 日付、時刻型への変換については、
#実はas_date関数はかなり優秀で、

as_date("2000/04/30")
as_date("20000430")
as_date("2000年4月30日")

#と、日本語表記でも変換できてしまいます。
#ただ、
as_date("4月30日(2000年)")
#こんな形であったり、
as_date("04302000")
#こんな形であったりするものは変換できません
#(数字の順番が大切だったりします）)
#
#こういう場合に活躍するのが、数字の並び順に年(year)
#月(month)、日(day)を指定できる

#ymd mdy dmy 等の関数です。

#例えば、4月30日(2000年)のような表記は、
#月、日、年の順番で数字が並んでいるので、
mdy("4月30日(2000年)")
#とすることでうまく変換できました。
#他に、もっと複雑な変換が必要な場合は、

?parse_date_time

#の例にあるように、

#日付と時刻が入り混じっているようなケースや
x <- c("09-01-01", "090102", "09-01 03", "09-01-03 12:02")
as_datetime(x)
parse_date_time(x, c("ymd", "ymd HM"))

#年月日の順番が途中でいれかわっているようなケース
x <- c("2009-01-01", "02022010", "02-02-2010")
as_date(x)
parse_date_time(x, c("dmY", "ymd"))

#何個か欠損しているケース
x <- c("2011-12-31 12:59:59", 
       "2010-01-01 12:11", 
       "2010-01-01 12",
       "2010-01-01")

as_datetime(x)
parse_date_time(x, "Ymd HMS", truncated = 3)
#truncatedで欠損して良い個数を指定すると
#NAにならずに変換できます。

#個人的にはこのparse_date_timeを駆使しないといけない
#データが出現した場合は、まずはstr_系の関数を利用して、
#少しキレイにすることを考えますが、
#利用できそうな場合は利用できると良いかもしれません。
#
#次は数字から日付型をつくる方法を解説していきます。

## Lec: 数字を日付・時刻型へ(sld97)------------

as_date(100)
as_datetime(100)
# で、起点となる日付や時刻からに日数や秒数で
# 時刻・日付を作成することはすでに解説しました。

#ただ、例えば、

dat <- tibble(
  yr = 1901:1910,
  mn = 1:10,
  dy = 1:10,
  hr = 1:10,
  min = 1:10,
  sec = 1:10
)

dat

#のように、数字で年月日 時間分秒が与えられた場合に、
#どのように時刻型や日付型に変換すればよいでしょうか?
#
#文字列型に文字列をくっつけてやる方法はあります。

str_c(1900,"-",10,"-",11," ",12,":",15,":",20) %>% 
  as_datetime()

#という方法ですが、これはなかなか煩雑です。
#実は、

lubridate::make_date(year=1900,month=12,day=20)
lubridate::make_datetime(year=1900, month=11, day=20, hour=12, min=20,sec=30)

#という感じで、make_ という関数を利用すれば数字で指定することが
#できるので、

make_date(1900,12,10)
make_datetime(1900,12,10,23,12,45)

#こんな感じで、数字の羅列で時刻・日付を
#作成することができます
#
#ということで、

dat2 <- dat %>% 
  mutate(
    d = make_date(yr,mn,dy),
    t = make_datetime(yr,mn,dy,hr,min,sec)
  ) 

dat2$d
dat2$t

#こんな感じで数字から日付、時刻型を作成してとりだすことが
#できます!

#さて、ここまででだいぶ日付や時刻を作成することができる
#ようになってきたと思います。
#次は、ここまであえて触れてこなかった
#
#[10] "1910-10-10 10:10:10 UTC"
#
#のUTCという部分について触れておきます。

## Lec: タイムゾーン(sld98)------------

#タイムゾーンという言葉を聞いたことはありますでしょうか？
#
#日本で夜の9時の時、アメリカでは朝のXX時というあれです。
#実は、Rは、日本時間と現地時間を換算するツールとして
#も利用できます。
#
#やってみましょう。

akasi <- as_datetime("2000-1-1 9:00:00",tz="Japan")

akasi

#日本の明石で2000年1月1日の朝9時だった場合は、
#tzをJapanと指定してあげてその時刻を作成することが
#できます。(そうすると、JSTという略がついていますね？)

#では、この時刻、アメリカのハワイ州ホノルルにある時計
#の時間(現地時間)であればどうなるでしょうか?

#Rなら簡単です

lubridate::with_tz(akasi, "Pacific/Honolulu")

#はい。1999年12月31日 14:00 HSTという結果でした。
#これがあれば、その土地のタイムゾーンを表すテキスト
#さえわかれば、自由自在に時刻を換算することができます。
#
#もちろん、これを覚えるのは大変なので、

OlsonNames()

#と入力してみましょう。
#2021aバージョンで593個もタイムゾーンがあるので、目的
#のものを利用してみてください。
#尚、OlsonNamesの関数名が若干覚えにくいので、
?tz
#と入力すると、説明の途中に、タイムゾーンのリストは
#OlsonNamesと入力しましょうとでてくるので、とりあえず
#?tzとだけでも覚えましょう。
#
#あと、今回はTZをJapanとしていますが、
#私の知る範囲、教科書等では、Asia/Tokyoが
#タイムゾーンになっていることが多いので
#JapanかAsia/Tokyoのどちらかを覚えておくと
#良いと思います。

#最後に、
force_tz(akasi,"UTC")
#と時刻の表示はそのままでタイムゾーンだけを変化させる
#ことも可能なので、必要に応じてご利用ください。

## Lec: 日付・時刻の計算(sld99)-------------------------

#　さて、ここまでで日付・時刻の基本的な知識はすべて解説
#　したので、ここからは計算について解説していきます。
#　
#　まず、ポイントとなるのは、日付・時刻同士は
#　「引き算しかできない」となります。

d1 <- as_date(10)
d2 <- as_date(2000)

d1
d2

#本当に引き算以外ができないか、確認してみましょう。
#(時刻と時刻を足す、時刻と時刻をかける、
#時刻と時刻をわるという行為そのものの意味もよくわかりません
#が、実験をするのは大事です)

d1 + d2
d1 * d2
d1 / d2

#できませんね?

#で、日付の引き算をしてみましょう。
d2 - d1　#うまくいきました。
minus <- d2-d1 #minusという変数にいれて
class(minus)　#classを調べます。

#「Time difference of 10 days」
#クラスは、difftimeというものになっています。

#数字や文字に返還してみましょう。

as.numeric(minus)
as.character(minus)

#このように日数を表していますね。
#このdifftime単純な日数差を計算するだけならこれでOKです
#ただ時刻型では、

t1 <- as_datetime(0)
t2 <- as_datetime(1)
t3 <- as_datetime(65)
t4 <- as_datetime(3605)
t5 <- as_datetime((3600*24)+5)
t6 <- as_datetime(366*((3600*24))+5)

min21 <- t2-t1
min31 <- t3-t1
min41 <- t4-t1
min51 <- t5-t1
min61 <- t6-t1

min21
min31
min41
min51
min61

#difftimeというclassであることには変わりないのですが、
#表示される単位が最小で秒から最大で日まで代わり、
#数字に戻すと、

as.numeric(min21)
as.numeric(min31)
as.numeric(min41)
as.numeric(min51)
as.numeric(min61)

#単位が違うままで印字されてしまいます。
#これ、計算するときにものすごく困るので、次の動画では
#時間同士の引き算をより正確に計算する方法
#について解説していきます。


## Lec: duration(sld100)------
#
# ひとつ前の動画では、時刻と時刻の差、difftimeが、長さ
# によって分や時間や日という単位に変わってしまい、計算
# 結果の単位が合わなくて困るという話をしました。
library(tidyverse)
library(lubridate)

t1 <- as_datetime(0)
t2 <- as_datetime(59)
t3 <- as_datetime(61)

m2 <- t2-t1
m3 <- t3-t1

m2
m3

as.numeric(m2)
as.numeric(m3)

# このdifftimeの困りごとを解消するためにはlubridateの
# Duration クラスを利用しましょう。

dur2 <- as.duration(m2)
dur3 <- as.duration(m3)

dur2
dur3

as.numeric(dur2)
as.numeric(dur3)
#いかがでしょうか?durationの表示は秒と分両方で記載
#されています。そしてas.numericで数字に変換した場合
#にdifftimeは単位がばらついた結果になっていましたが、
#durationは数字になってかつ、
#単位も秒で統一されていますね

#日付型もみてみましょう
dy1 <- as_date(0)
dy2 <- as_date(100)
dy3 <- as_date(1000)

dur2 <- dy2 -dy1
dur3 <- dy3 -dy1

as.duration(dur2)
as.duration(dur3)

#はい。この通り、やはり秒で表示されており、
#()の中に、週であったり年であったりが表示されています
#
#durationを利用することで秒で統一的に時刻や日付の差を
#計算することができます。
#
#このduration、lubridateに用意されている関数で
#「経過時間」を作成することができます。
#
#ちょっとやってみましょう。
#例えば、
#2020年12月30日の朝9時の24時間後の時刻を計算してみます。
#「24時間」をduration型で作成するには

hr24 <- lubridate::dhours(24)
hr24

#このようにdhoursを利用します。

#lubridate::dと検索すると、dmonth dyear dminutes 等の
#durationを作成するための関数がありますので必要に応じて
#利用してください。それで、このhr24を、
t1 <- as_datetime("2019-3-1 09:00:00")

#t1に足してあげましょう。
t1 + hr24

#24時間後の時刻になっていますね?
#このように、好きな時間をdurationで作成して時刻に対して
#足すことで「時間をすすめること」ができます。

#日付型でもやってみましょう。
dy1 <- as_date("2020-2-20")

dy1 + ddays(5) #無事、5日後の日付になっていますね?

#これ1か月後とかもできるんですが・・・
dy1 + dmonths(1)

#??? なぜか日付ではなく時刻になっています。
#実は、
dmonths(1)
#は、4.35週間ときっちり「カレンダー上の1か月」ではありません
dyears(1)/12
#1年の長さを単純に12分の1にしただけなので、
#カレンダー上の1か月後という意味では間違いとなってしまいます。
#ちなみに、計算してみると
as.numeric(months(1)) #秒
as.numeric(months(1))/60 #分
as.numeric(months(1))/60/60 #時間
as.numeric(months(1))/60/60/24 #日

#ということで30.4375日、物理的な時間を進めるのが、
# + dmonths(1)
#という処理になります。
#
#以上、durationについての説明でした。
#物理的に経過した時間を計算するためには、
#このdurationは非常に便利です。
#ただし、月や年等をカレンダーで考えたい場合
#は、durationを使いづらいので、次は
#カレンダーの数値を変更する感覚で計算できる、
#periodについて解説していきます。
#
## Lec: period(sld101) --------------------------
#それでは、カレンダーの日付を変更するようなを計算していきましょう。
#これ、実は簡単で、dyears、dmonthsではなくて、
#years、monthsという関数で処理をすれば実現できます。

months(1)

#durationと違う表記ですね?
class(months(1))

#このperiodクラスを日付に足していってみましょう。

dy1 <- as_date("2020-2-20")
dy2 <- dy1 + months(1)
dy3 <- dy2 + months(1)

#きっちりカレンダーの数字を変更させただけですね。
#ここでちょっと注目いただきたいのは、

as.numeric(dy3 - dy2)
as.numeric(dy2 - dy1)

#months(1)は、「物理的な時間」を無視して
#単純に月の数字だけを増加させている
#という形になります。

#duration、period、特徴を理解して適切な場面で
#使わないと、時刻・日付計算で予想しないような
#エラーが生じる場面もありますので、
#是非、ここでなんとなくでもいいので違いを
#押さえておいてください。
#
#periodを利用する場合の注意点として、架空の日付が
#生成される場合があることです。やってみましょう。
dy1 <- as_date("2020-01-31")

#2020-1-31の1か月後という処理を行うつもりで、
dy1 + months(1)
#とすると、NAとなります。
#これは、
#  2020- 01- 31
#        +1
#  2020- 02- 31

#という風に、2月31日という存在しない日付になってしまったから
#です。

#このような場合だと、条件を考えて操作をしないと
#いけないので結構てまです。
#lubridateには、こういうケースでエラーが出ないように
#するための+と-の特別な記号がlubridateに含まれており

dy1
dy1 + months(1)
dy1 %m+% months(1)

dy1 - months(2)
dy1 %m-% months(2)

#こんな感じで計算することができます。
#ということでPeriodの紹介でした。

## Lec::interval(sld102)---------------

# さて、ここまでは、ある時刻は日付に対して、
# 一定の時間経過(物理的:duration　カレンダー:period)を
# 足したり引いたりする話をしてきましたが、
# 時間を扱う場合に、
# 「時間の幅」と「時間の幅」を比較したいようなケースが
# あります。
# 
# 例えば、ある薬1の投与期間が2000年1月1日から2月1日まで
# で、薬2の投与期間が2000年1月10日から2月10日までであった
# 場合に、この二つの期間が重複しているかを調べたいような
# ケースだと

m1s <- as_date("2000-1-1")
m1e <- as_date("2000-2-1")

m2s <- as_date("2000-1-1")
m2e <- as_date("2000-3-1")

#m1s --------- m1e
#         m2s-----------m2e
#
#m2s --------- m2e
#         m1s ----------m1e

#という形で、どちらが先に来るか等の場合わけを
#含めて考えないといけません。

#こういう場合は、intervalという「幅をもった」
#型を使いましょう。

int1 <- interval(m1s, m1e)
int2 <- interval(m2s, m2e)

int1
int2

#このような形にすることで、
#二つの期間が重なっているか?
int_overlaps(int1,int2)

#二つの期間の開始時期が一致しているか
int_aligns(int1,int2)

#等のTRUE・FALSEが簡単に集計できます。

#以上、簡単ですがIntervalの解説でした。
#次の動画からはここまで
#の知識を利用して時間の集計
#を行っていきます。

## Lec::時間の集計1(sld103)-----------------
{
  library(tidyverse)
  library(lubridate)
  dt1 <- as_date("2020-4-1") %>% as.numeric()
  dt2 <- as_date("2020-6-1") %>% as.numeric()
  
  set.seed(123466)
  gen_single_id <- function(id){
    num_med <- sample(1:3,1)
    
    tibble(med = sample(LETTERS[1:3],num_med,replace = TRUE),
           start = sample(dt1:dt2,num_med, replace=TRUE),
           end = start + sample(1:100, num_med, replace=TRUE))
  }
  
  dat <- tibble(id = 1:200) %>% 
    mutate(ddd = map(id, gen_single_id))
  
  dat <- dat %>% 
    unnest(c(ddd)) %>% 
    arrange(id, med) %>% 
    mutate(across(c(start,end), ~{as.character(as_date(.))}))
  
  write_csv(dat,"data/time.csv")
  
}

#それでは、引き続きスライドで解説した、
#時間に関する集計についてデータを読み込んで処理
#を行うことを練習してみましょう。

dat <- read_csv("data/time.csv")

dat

#このデータも、私が作成した架空のデータです。
#idは対象者、medは処方された薬、startとendで
#処方開始(start)と終了(end)を記載してあります。
#
#
#まず、このデータ全体を眺めてみましょう。

dat %>% summary()

#summary関数を利用するとおおむねの情報が表示されます。
#ただし、med変数については文字列であるとだけしか
#表示されていないので、因子型に変更しておきましょう

dat2 <- dat %>% mutate(med = as.factor(med))

dat2 %>% summary()

#これで、このデータは、idが1から200まで、200人分
#のデータで、このデータにでてくる薬の種類は、
#A、B、Cの3種類であることがわかります。
#
#また、

dat2 %>% count(id, med)

#でさらっと見ると、nが2等も見当たるので、
#二回同じ薬が同じIDで処方されているデータになっている
#こともわかります。
#
#countのこの形だとちょっと見ずらいので、base::table
#関数をこういう場合に利用すると便利です。

table(dat2$id, dat2$med) %>% head() #あるいは、

dat2 %>% {table(.$id, .$med)} %>% head()

#{}でくくると、　DATA %>% {}　として、{}の中の「.」が
#DATAと同じになるので、データの名前がめちゃくちゃ長い場合、

nanika_monosugoku_namae_ga_nagai_data <- dat2 

table(
  nanika_monosugoku_namae_ga_nagai_data$id,
  nanika_monosugoku_namae_ga_nagai_data$med
) %>% head()

nanika_monosugoku_namae_ga_nagai_data %>% 
  {table(.$id, .$med)} %>% 
  head()

#すっきりと書くことができます。
#
#
#それではここからは、問題に答える形で解説をすすめていきます

#問題:
#薬AからC、それぞれの投与期間を日数で
#最小、平均、最大値を集計してみましょう
#尚、重複して投与されている場合は、

#|----A1-----|
#               |-----A2-----|
#               
#このように期間がかぶっていない場合は、どちらか長い方を
#採用、
#
#|----A1----|
#    |-----------A2------|
#    
#このように期間がかぶっている場合は、1つの期間として
#集計する。
#
#というルールでやってみてください。
#次の動画では、どのように処理するかのイメージを解説していきます

#set.seed(12345)

{ #
  plot_dat <- function(dat, xrange=c(1,100)){
    gt <- dat %>% 
      mutate(id = n():1) %>% 
      ggplot() +
      geom_segment(aes(x = s, xend = e, y = id, yend = id))  +
      geom_point(aes(x = s, y=id),color="orange") +
      geom_point(aes(x = e, y=id),color="darkblue") +
      theme_void()+
      coord_cartesian(xlim=c(as_date(xrange[1]),as_date(xrange[2])))
    
    gb <- dat %>% 
      ggplot() +
      geom_segment(aes(x=s,xend=e,y=1,yend=1))+
      geom_point(aes(x=s,y=1),color="orange") +
      geom_point(aes(x=e,y=1),color="darkblue") +
      theme_void()+
      coord_cartesian(xlim=c(as_date(xrange[1]),as_date(xrange[2])))
    
    cowplot::plot_grid(gt,gb,nrow=2,rel_heights = c(7,1))
  }
  
  
  dat <- tibble(
    s = sample(1:100, 10, replace = TRUE),
    e = s + sample(1:10, 10, replace = TRUE)
  ) %>% 
    mutate(s = as_date(s),
           e = as_date(e))
  
  dat <- tribble(
    ~s, ~e,
    1,  2,
    3,  5,
    5,  6,
    5,  8,
    9, 11
  ) %>% 
    mutate(s=as_date(s), e=as_date(e))
  
  plot_dat(dat, c(1,15))
  
  dat %>%
    arrange(s) %>%
    mutate(interv = interval(s,e)) %>%
    mutate(prev_overlap = int_overlaps(interv, lag(interv))) %>% 
    replace_na(list(prev_overlap=FALSE)) %>% 
    mutate(presc_id = cumsum(!prev_overlap)) %>% 
    group_by(presc_id) %>%
    summarise(s = min(s), e = max(e))
  
  dat2 <- dat %>% 
    arrange(s) %>% 
    mutate(interv = interval(s,e)) %>% 
    mutate(post_overlap = int_overlaps(interv, lead(interv))) %>% 
    mutate(new_e = if_else(post_overlap, lead(e), e, e)) %>% 
    mutate(e = if_else(post_overlap, new_e, e, e))
  
  View(dat2)
  plot_dat(dat2)  
  
  check_overlap <- function(.data){
    temp <- .data %>% 
      mutate(new_interval = interval(s,e,tzone = "UTC"))
    
    temp <- temp %>% 
      mutate(
        new_int_next = int_overlaps(new_interval, lead(new_interval))
      )
    
    any(temp$new_int_next, na.rm=TRUE)
  }
  
  run_test <- function(x){
    print(x)
    set.seed(x)
    dat <- tibble(
      s = sample(1:100, 10, replace = TRUE),
      e = s + sample(1:10, 10, replace = TRUE)
    ) %>% 
      mutate(s = as_date(s),
             e = as_date(e))
    
    
    dat2 <- dat %>% 
      arrange(s) %>% 
      mutate(interv = interval(s,e)) %>% 
      mutate(
        prev_overlap = int_overlaps(lag(interv),interv),
        post_overlap = int_overlaps(interv, lead(interv))
      ) %>% 
      mutate(
        new_e = if_else(post_overlap, lead(e), e)
      ) %>% 
      mutate(e = new_e) %>% 
      filter(!post_overlap)
    
    return(check_overlap(dat2))
  }
  
  res1 <- map_lgl(100:1000, run_test)
  
}

## Lec::時間の集計2-イメージ1-----------------

#slide:105-116

## Lec::時間の集計3-イメージ2-----------------

#slide:117-125

{
  dat <- read_csv("data/time.csv")
  
  dat <- dat |> 
    slice(1:5) |> 
    select(start,end)
  
  dat %>%
    arrange(start) %>% 
    mutate(interv = interval(start, end)) %>% 
    mutate(
      prev_overlap = int_overlaps(interv, lag(interv)),
      prev_nextday = int_overlaps(interv, int_shift(lag(interv),days(1))),
    ) %>%
    mutate(prev_oa = prev_overlap | prev_nextday) %>% 
    replace_na(list(prev_oa = FALSE)) %>% 
    mutate(presc_id = cumsum(!prev_oa)) %>%
    group_by(presc_id) %>% 
    summarise(start = min(start), end = max(end))

  
}

## Lec::時間の集計4 Rで実施1(sld126)-----------------

library(tidyverse)
library(lubridate)

dat <- read_csv("data/time.csv")

#まず、このデータ、選んだIDを図示してみます。
#(解説のための図なので、スクリプトの内容は解説しません)

plot_id <- function(.data,tgt_id){
  gdat <- .data %>% 
    filter(id %in% tgt_id) %>% 
    mutate(row_n = n():1) %>%
    mutate(points = map2(start,end, ~{.x:.y})) %>% 
    select(id,med,row_n,points) %>% 
    unnest(c(points)) %>% 
    mutate(points = as_date(points))
  
  ggplot(gdat) +
    geom_point(aes(x = points, y = as.factor(row_n), color = med)) +
    scale_y_discrete(labels=NULL) +
    facet_wrap(~id, scales = "free")
}

#このplot_id関数、
plot_id(dat,c(1,15,20))

#こんな感じで、x軸に日付、y軸に行として、
#点で処方期間を描画してくれています。
dat %>% filter(id ==20)
#ここで、課題としては、例えばid20番の青色の点、
#薬Cの投与期間が重複しているため、これを
#1つの期間としてまとめたいという形です。

#データで、2行より多く行数があるidを抜き出しておきましょう。

id_with_gt2r <- dat %>% 
  count(id) %>% 
  filter(n > 2) %>% 
  pull(id)

id_with_gt2r
#これは

dat %>% count(id)
#で、idの数をそれぞれ数えて、nが2より大きいものだけに
#しぼりこんで、pull関数でベクトルとしてidを抜き出しています

#実際にどのようなデータがあるか確認しておきます
plot_id(dat,id_with_gt2r[1:9])
plot_id(dat,id_with_gt2r[10:18]) 
plot_id(dat,id_with_gt2r[19:27]) 
plot_id(dat,id_with_gt2r[28:36]) 
plot_id(dat,id_with_gt2r[37:45]) 
plot_id(dat,id_with_gt2r[46:54]) 
plot_id(dat,id_with_gt2r[55:61])


#それでは、スライドでお示ししたスクリプトで
#処理を行っていきましょう
#ここでは、

plot_id(dat,id_with_gt2r[11])

#このデータをきれいにすることをまずは考えます。
temp <- dat %>% 
  filter(id == 39) %>% 
  select(start,end)

#ID39 は薬剤Cについて３つの期間が含まれるデータなので、
#スライドでの解説で行った形のデータになっています。

temp %>% 
  arrange(start) %>% #並びかえて 
  mutate(interv = interval(start, end)) %>% #intervalを作成して 
  mutate(
    prev_overlap = int_overlaps(interv, lag(interv)),
    prev_nextday = int_overlaps(interv, int_shift(lag(interv),days(1))),
  ) %>% #期間の重なりを確認
  mutate(prev_oa = prev_overlap | prev_nextday) %>% #２条件を１つにまとめて 
  replace_na(list(prev_oa = FALSE)) %>% #欠損はFALSEで置き換え
  mutate(presc_id = cumsum(!prev_oa)) %>% #TRUE FALSEをひっくり返して累積和
  group_by(presc_id) %>%  # 累積和（塊）毎にグループを作って
  summarise(start = min(start), end = max(end)) # 各グループの最小・最大で集計する

#と、こんな感じでうまく、５月１日までの塊と、５月８日移行の塊に
#分けることができました。

#この処理、同じIDの同じ薬内での処理になっていますが、
#これを別々のIDと薬剤に処理してあげる必要があります。
plot_id(dat,id_with_gt2r[1:8])

#上で書いたスクリプトは、それぞれのID内で、同じ薬剤での
#処理となります。
#
#ここで課題です。上のスクリプトを利用して、ID毎、ID毎の薬剤毎に
#上のスクリプトを適応する処理を書くことはできますか？
#
#次の動画でIDと薬剤を加味したスクリプトを解説していきますが、
#できればまずご自身で可能か、取り組んでみてください。

## Lec::時間の集計4 Rで実施2(sld126)-----------------

#ここまでの解説では、各IDの薬剤毎ということは加味
#しておりませんでしたが、ここからはそこも加味して処理
#を書いていきます。
#
#ご自身で試みてみましたか？
#この処理ですが、id列とmed列を含んだ処理を書いてく形です
#やってみましょう

dat2 <- dat %>% 
  arrange(id,med,start) %>% #ここにmed,startを追加  
  mutate(interv = interval(start, end)) %>%  #同じ
  group_by(id, med) %>%  #idとmedでグループ化
  mutate(
    prev_overlap   = int_overlaps(interv, lag(interv)),
    prev_edgealign = int_aligns(interv, lag(interv)),
  ) %>% 
  mutate(prev_oa = prev_overlap | prev_edgealign) #グループ化後は同じ

View(dat2)
#うまく、重複・期間の端が隣接している行をTRUEとふれていますね？

#あとは、NAをFALSEで埋めてあげて、
dat3 <- dat2 %>% 
  replace_na(list(prev_oa = FALSE))

View(dat3)

#各IDの各処方毎、処方期間の重複をふくめて、IDを振ってあげます。
dat3
#にかけたグループはまだそのまま残っているので、単純に、
#mutateするだけでよくて、ここも、処理内容は変わりません
dat4 <- dat3 %>% 
  mutate(presc_id = cumsum(!prev_oa)) 

plot_id(dat, c(39,140))
dat4 %>% 
  filter(id %in% c(39,140)) %>% 
  select(id,med,start,end,presc_id)

#いかがでしょうか?うまく、「重複毎」に、presc_idが
#振られていますね?
#後は、

dat5 <- dat4 %>%
  group_by(id, med, presc_id) %>% #グループを作り直し。id,medを追加
  summarise(start = min(start), end = max(end)) # 同じ

#うまくいきました。
#尚、ここで、ちょっとだけ注意が必要なのが、summarise実行時
#にでているメッセージです
#
#`summarise()` has grouped output by 'id', 'med'.
# You can override using the `.groups` argument.
# 
# とあるのですが、これは、summarise実行ででてきた
# 結果に「id med」の二つのグループが残っているという
# メッセージです。
# 実際、
dat5

# で確認すると確かにグループが残存しています。
# sumariseでは最後のグループだけが解消されるイメージです。
# このグループを消したい場合は、
dat5 %>% ungroup()

#とグループを消す処理を意図的に入れてあげるか、
dat4 %>%
  group_by(id, med, presc_id) %>% 
  summarise(start = min(start), end = max(end), .groups = "drop")

#と、summariseの時点で.group引数に"drop"を与えると
#summarise時点でgroupが消えます。こちらの方法、
#本コースを作成している時点では、実験的な機能なので、
#将来使えなくなる可能性もあるのでその点ご留意ください。
#このコースでは、ungroupを主に利用します。それで、

dat_fin <- dat5 %>% 
  ungroup() %>%
  arrange(id,med,start) #並び替えておきます。

#これで完成です。
#可視化して確認しておきましょう

compare_plot <- function(.data1, .data2, tgt_id){
  pre_graph  <- plot_id(.data1, tgt_id)
  post_graph <- plot_id(.data2, tgt_id)
  
  cowplot::plot_grid(pre_graph, post_graph, nrow=2)
}

compare_plot(dat,dat_fin,c(2,5,10))

#上のグラフがもとのもので、下のグラフが処理後のものです
#うまく期間が一つにID、薬毎にまとまっていますね？

#ただし、今回の処理、一つ上のものとの比較だけをしているため、

compare_plot(dat,dat_fin,c(39,93,140))

#id 93番が想定した結果と少し違います。これ、なぜかわかりますか？
#少し考えてみてください。次の動画で解説していきます。

## Lec::時間の集計4 Rで実施3(sld126)-----------------
#
#それでは、93番のデータが想定とちがった理由を確認しておきます
#これは、
compare_plot(dat,dat_fin,93)

#                             prev_overlap   cumsum(!prev_oa)
# |-------------------|            FALSE         1
#   |-----|                        TRUE          1
#               |--------------|   FALSE         2

#このようなパターンとなっているため、
#処理をした結果が、
               
# |-------------------|            
#               |--------------|

#こうなっていて、処理自体は正しく終わっているのですが、
#うまくくっついていないケースです。
#これへの対応は色々と考えられますが、ここでは、
#処理を複数回繰り返して対応しましょう。
#上の形に対して同じ処理を繰り返すと、最終的には

# |----------------------------|            

#こうなるはずです。
#
#「処理」を行数の変化がなくなるまで
# 複数回実行してあげて全部の行を一つにまとめましょう。
# できますか？

dat_n1 <- dat %>% 
  arrange(id,med,start) %>% 
  mutate(interv = interval(start, end)) %>% 
  group_by(id, med) %>% 
  mutate(
    prev_overlap = int_overlaps(interv, lag(interv)),
    prev_nextday = int_overlaps(interv, int_shift(lag(interv),days(1))),
  ) %>%
  mutate(prev_oa = prev_overlap | prev_nextday) %>% 
  replace_na(list(prev_oa = FALSE)) %>% 
  mutate(presc_id = cumsum(!prev_oa)) %>%
  group_by(id, med, presc_id) %>% 
  summarise(start = min(start), end = max(end)) %>% 
  ungroup() %>% 
  select(id, med, start, end)  

#これが１回目の処理です。
#行数の変化は、
nrow(dat)
nrow(dat_n1)

#ですね。
#もう一度。
dat_n2 <- dat_n1 %>% 
  arrange(id,med,start) %>% 
  mutate(interv = interval(start, end)) %>% 
  group_by(id, med) %>% 
  mutate(
    prev_overlap = int_overlaps(interv, lag(interv)),
    prev_nextday = int_overlaps(interv, int_shift(lag(interv),days(1))),
  ) %>%
  mutate(prev_oa = prev_overlap | prev_nextday) %>% 
  replace_na(list(prev_oa = FALSE)) %>% 
  mutate(presc_id = cumsum(!prev_oa)) %>%
  group_by(id, med, presc_id) %>% 
  summarise(start = min(start), end = max(end)) %>% 
  ungroup() %>% 
  select(id, med, start, end)  

#すると、
nrow(dat)
nrow(dat_n1)
nrow(dat_n2)

#1行減りました。ということはこれ以上変化しないはずですが、
#念のため、
dat_n3 <- dat_n2 %>% 
  arrange(id,med,start) %>% 
  mutate(interv = interval(start, end)) %>% 
  group_by(id, med) %>% 
  mutate(
    prev_overlap = int_overlaps(interv, lag(interv)),
    prev_nextday = int_overlaps(interv, int_shift(lag(interv),days(1))),
  ) %>%
  mutate(prev_oa = prev_overlap | prev_nextday) %>% 
  replace_na(list(prev_oa = FALSE)) %>% 
  mutate(presc_id = cumsum(!prev_oa)) %>%
  group_by(id, med, presc_id) %>% 
  summarise(start = min(start), end = max(end)) %>% 
  ungroup() %>% 
  select(id, med, start, end)  

nrow(dat)
nrow(dat_n1)
nrow(dat_n2)
nrow(dat_n3)

#はい。確かに変化していないので問題なく結合できているはずです。
#93番を見てあげると、
compare_plot(dat,dat_n1,93)
compare_plot(dat_n1,dat_n2,93)
#確かに結合されていますね？

#この処理方法、時間もかかるし面倒なので、本来であれば
#　繰り返し処理
#　関数化
#
#などで対応しますが、少し抽象度が高い概念となるため、
#本コースでは以下に例示をするだけにとどめます。
#
#もっと勉強してみたいという方は、別のコースを確認ください。

#例示：
#関数を作成する
process_data <- function(.data){
  fin <- .data %>%
    arrange(id,med,start) %>% 
    mutate(interv = interval(start, end)) %>% 
    group_by(id, med) %>% 
    mutate(
      prev_overlap = int_overlaps(interv, lag(interv)),
      prev_nextday = int_overlaps(interv, int_shift(lag(interv),days(1))),
    ) %>%
    mutate(prev_oa = prev_overlap | prev_nextday) %>% 
    replace_na(list(prev_oa = FALSE)) %>% 
    mutate(presc_id = cumsum(!prev_oa)) %>%
    group_by(id, med, presc_id) %>% 
    summarise(start = min(start), end = max(end)) %>% 
    ungroup() %>% 
    select(id, med, start, end)
  return(fin)
}

#繰り返し処理を行う
iter_data <- dat
prerows <- nrow(iter_data)
postrows <- 0 
while(postrows != prerows){
  prerows <- nrow(iter_data)
  print(prerows)
  iter_data <- process_data(iter_data)
  postrows <- nrow(iter_data)
  print(postrows)
}

#処理終わり！

#ということで関数とwhileなどの
#繰り返し処理を利用すると、すっきりと書くことができます。

#最後に、ここで処理したデータを利用して、最初に求めようと
#していた、薬A、B、Cの投与期間の最小値、最大値、平均値
#をもとめてみましょう。

dat_n3

dat_n3 %>% 
  group_by(med) %>% 
  summarise(
    min_kikan = min(end-start),
    max_kikan = max(end-start),
    avg_kikan = mean(end-start)
  )

#できました!
#いかがでしょうか?

#だいぶ複雑でしたが、
#少し工夫して計算することで
#日付の幅等の集計を行うことができました。
#
#お疲れさまでした。以上で集計に関する内容はおしまいです。

#補足として、intervalを利用しないで
#同様の処理を行う方法を次の動画で解説しておりますので、
#よろしければどうぞ。
#
#必要ないという方は次のセクションにお進みください

## Lec::時間の集計 補足-----------------

#ここまでの動画で紹介した処理、
#intervalを利用する方法ですが、結構時間がかかってしまっています
#R（といいますかプログラミング全般）では、課題の解決に
#発想を変えると色々簡単になったり、はやくなったりすることも
#多いので、違うやり方をここでは説明してみます。
#
#解説の都合上、intervalを使って処理するという縛りを
#自分にかしていたため、この補足動画では、intervalを
#全く利用せずに、繰り返し処理を利用しない方法を考えてみます。

#この方法、本コースで扱う処理の範囲外となるので、
#学んでいくとこんな処理も可能なんだ！というくらい
#の気持ちでみていただけると幸いです。


#処理の基本的な考え方、
#日付を利用するまえに数字で確認しておきましょう。

d <- tribble(
  ~id,~m,~s,~e,
  1,1,1,12,
  1,1,3,5,
  1,1,7,14,
  1,1,16,18,
  1,1,19,20
)

d

#このようなデータがあるとして、idは個々の人、
#mは薬のid、sは開始日、eは終了日だとします。
#
#このとき、

#| id | m | s  | e  |
#|  1 | 1 | 1  | 14 |
#|  1 | 1 | 16 | 20 |

#こうなってほしいはずです。
#これ、期間の前後比較をする
#のではなく、処方された日をまず抽出してから期間を
#考えるというアプローチをとります。

#まず、全ての処方された日を含むベクトルを作成します
#これ、例えば１行目なら１から１２、
#２行目なら３から５といった具合です。

v <- c(1:12,3:5,7:14,16:18,19:20)
v

#このベクトルに含まれる数字が処方された日なので、
#uniqueで重複を消してからorderで並び替えます

v2 <- v  %>% unique() %>% {.[order(.)]}
v2

#このベクトルv2に含まれるのが全ての処方日なので、
#このベクトルの連続した数字の最初と最後を抜き出すと
#目的の値となります。なので、後は最初のやり方と
#同じ発想で
#
tibble(x = v2) %>%
  mutate(diff = x - lag(x)) %>%
  replace_na(list(diff=1)) %>%
  mutate(prescid = cumsum(diff > 1)) %>%
  group_by(prescid) %>%
  summarise(s = min(x), e = max(x))

#目的とする形にできました。
#この方法の利点は、
#全ての範囲をまとめてから範囲の計算をするため、
#複数回の実行が必要ないところです。
#
#デメリットとしては、ネストしたデータフレームという
#最初に学ぶ時点では少し難易度が高いデータ構造を
#取り扱う点です。
#
#ネストしたデータフレームの詳細については、
#本コースの対象外です。たいていの表データの処理は、
#本コースで解説した関数を利用すれば大きな問題なく
#できるはずなので、まずは本コースの内容にある程度
#習熟してから、次のような書き方を学んでみてください。
#
#それでは、処理を簡単に解説しながら行っていきます。

#データの読み込み
dat <- read_csv("data/time.csv")

#ネストしたデータの作成
dat2 <- dat %>%
  group_by(id,med) %>%
  nest()

dat2
#このnestしたデータですが、data列が
#見慣れないものになっていると思います
#
#これ、リスト列と呼ばれるもので、
#１行に１個のtibbleを入れたり、
#１行に１個のグラフを入れたり、
#
#tibbleのセルの中にオブジェクトを入れる
#ことができるという形です。
#こうすることで、dplyrやtidyrを
#駆使した複雑な処理を、group_byでは
#できない形で１個ずつの「表」に
#適応することが可能となります

#一つの表に対する処理の関数
proc_row <- function(adata){
  v <- map(1:nrow(adata), ~{
    d <- slice(adata,.)
    c(d$start:d$end)
  }) %>% 
    unlist() %>%
    unique()
  
  r <- tibble(x = v) %>%
    arrange(x) %>%
    mutate(diff = x - lag(x)) %>%
    replace_na(list(diff=1)) %>%
    mutate(prescid = cumsum(diff > 1)) %>%
    group_by(prescid) %>%
    summarise(s = min(x), e = max(x))
  
  return(r)
  
}

#この関数、何をするかというと、

#先ほどのデータ列の１つのセルの中身が
#こんな表だとして、
dat2$data[[13]]

#関数を適応するとこうなります
proc_row(dat2$data[[13]])

#数字になってしまっていますが、
#日付型に変えると、うまく変換されている
#はずです

#で、この関数をdata列の各行一つ一つに
#適応していきます。
#普通にmutateしてもうまくいかないので、
#map関数という関数を利用します。

dat3 <- dat2 %>%
  mutate(res = map(data,proc_row))

dat3

#これで、新しく作成されたres列には、
#data列に含まれていた各表に対して、
#proc_row関数を適応した結果が
#挿入されています
#
#あとは、このres列をリストではなく、
#普通の表として取り出してもとの
#id,medにくっつけてあげるて、
#数字ではなく日付型に戻しておきます

alternate <- dat3 %>%
  select(id, med, res) %>%
  unnest(res) %>%
  select(!prescid) %>%
  ungroup() %>% 
  mutate(across(c(s,e),as_date))

alternate

#この、別の方法をとって作成した
#alternateと、ひとつ前の動画までの
#やり方で作成したdat_n3の集計結果
#が一致するかを確認しておきましょう

dat_n3 %>% 
  group_by(med) %>% 
  summarise(
    min_kikan = min(end-start),
    max_kikan = max(end-start),
    avg_kikan = mean(end-start)
  )
  
alternate %>% 
  group_by(med) %>% 
  summarise(
    min_kikan = min (e-s),
    max_kikan = max (e-s),
    avg_kikan = mean(e-s)
  )

#いかがでしょうか？
#集計結果は一致していますね？
#
#なれると、複雑な加工は、
#nestしたデータに対して、処理を
#行う形をすると、すっきりと書くことが
#できるので、必要があれば
#この書き方を試していただいてもよいと
#思います。
#
#それでは、最後のセクション、
#レポートの作成に進んでいきましょう