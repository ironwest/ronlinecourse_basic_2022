#セクション5 パート2 現実のデータのtidy化演習

## Lec: パート2の概要----------

#ここからは、
#　1私が作成した看護記録もどき.xlsxの加工
#　2厚生労働省のオープンデータ:人口動態統計のtidy化
#　3厚生労働省のオープンデータ:食中毒統計データのtidy化

#を行いながら、汚いデータをキレイにする工程
#を一緒に経験していきましょう。
#それでは、よろしくお願い申し上げます。


## Lec: 看護記録もどきの加工1----------------

#それでははじめます。
#必要なパッケージの読み込みましょう
library(tidyverse)
library(readxl)

#まずはインポートです。

kiroku <- readxl::read_excel("data/看護記録もどき.xlsx")

View(kiroku)

#だいぶややこしいですが順番に考えていきます。

#まず、「患者名」列をなんとかしましょう

kiroku %>% select(`患者名`)

#患者名の下に、それぞれの測定項目の
#名前が記載されているため、
#「患者名」の列をもとに、nameという
#列を作成して、そこに、患者名を埋めていく
#ようにしてみましょう。

#注目する列だけを抜き出して変化をみると、

kiroku %>% 
  select(`患者名`) %>% 
  mutate(name = 
           if_else(
             str_detect(`患者名`,"^\\s"), 
             NA_character_,
             `患者名`)) %>%
  fill(name)



#こんな感じで、Aさんの行なのかBさんのデータがある
#行なのか、name列を見ることで班別することができる
#ようになりました。

kiroku2 <- kiroku %>% 
  mutate(name = 
           if_else(
             str_detect(`患者名`,"^\\s"), 
             NA_character_,
             `患者名`)) %>%
  fill(name)

kiroku2  

#次に、「患者名」列からすでに患者名は
#とりだしたので、名前を、「測定項目」
#として、並び替えておきます

kiroku3 <- kiroku2 %>% 
  select(name, sokutei = `患者名`, everything())

# selectでもrenameと同じ書き方できたの覚えています
# か？また、everything()とすることで、
# 残りの列も選択できるので
# 変数名を変えながら並び替えることができます。


#次に、sokutei列で、患者名が書いてある行は
#入退院に関するデータが含まれているので、
#その行をadmissionと書き換えます。
#
#列だけ取り出して変換をみてみると、
kiroku3 %>% 
  select(sokutei) %>% 
  mutate(sokutei2 = 
           if_else(str_detect(sokutei,"^\\s"),
                   sokutei, "admission"))

#こんな感じで、sokutei列のスペースが先頭にあれば
#もとのまま、なければadmissionに書き換えるという
#処理を行います。

kiroku4 <- kiroku3 %>% 
  mutate(sokutei = if_else(
    str_detect(sokutei,"^\\s"),
    sokutei, "admission"
  ))

kiroku4

#これで各行に対してsokuteiコラムでラベルを
#つけることができたので、先頭の余分なスペース
#を削除してからタテのデータに変換します

temp <- kiroku4 %>% 
  select(sokutei) %>% 
  mutate(sokutei2 = str_trim(sokutei))

str_view_all(temp$sokutei,"\\s")
str_view_all(temp$sokutei2,"\\s")

#スペース、消えていますね?

kiroku5 <- kiroku4 %>% 
  mutate(sokutei = str_trim(sokutei))

kiroku5

#ここまできたら、これは横持ちデータで、
#日付のデータが列名になってしまっている形
#なのでpivot_longerで縦持ちデータに直しましょう

kiroku6 <- kiroku5 %>% 
  pivot_longer(cols = !c(name,sokutei),
               names_to = "date",
               values_to = "val")

kiroku6

#NAとなっている部分はデータが存在しないので
#消します。

kiroku7 <- kiroku6 %>%
  filter(!is.na(val))

kiroku7

#最終的にどのような形にもっていきたいかで
#この先の処理は変わります。
#次の動画では、この先の処理の一例をお示しします。

## Lec: 看護記録もどきの加工2----------------

#例えば処理例として、

wide <- kiroku7 %>% 
  pivot_wider(
    id_cols = c(name, date),
    names_from = sokutei,
    values_from = val
  ) %>% 
  arrange(name, date)

#で、sokutei項目毎の列を入れたwideデータに
#変換して、

View(wide)

wide2 <- wide %>% 
  rename(bp = `血圧`, pulse = `脈拍`, rr = `呼吸回数`, meal = `食事`)

#変数名を英語に変えておいて、

wide2 %>% 
  select(bp) %>% 
  separate(bp,c("am","pm"),sep="-", remove=FALSE) %>% 
  separate(am,c("am_sbp","am_dbp"), sep="/",remove=FALSE) %>% 
  separate(pm,c("pm_sbp","pm_dbp"), sep="/",remove=FALSE) %>%
  mutate(
    am_sbp = str_trim(am_sbp) %>% na_if(""),
    pm_sbp = na_if(pm_sbp,"")
  )

#こんな感じで、bp列を午前と午後のSBP、DBP、計4つの
#列に分割します。

#同じように、脈拍、

wide2 %>% 
  select(pulse) %>% 
  separate(pulse,c("am_pulse","pm_pulse"), remove=FALSE) %>% 
  mutate(pm_pulse = na_if(pm_pulse,""))

#呼吸回数
wide2 %>% 
  select(rr) %>% 
  separate(rr,c("am_rr","pm_rr"),
           sep="-",remove=FALSE) %>% 
  mutate(
    am_rr = str_replace(am_rr,"回",""),
    pm_rr = 
      str_replace(pm_rr,"回","") %>% 
      str_trim() %>% 
      na_if("")
  )

#食事
wide2 %>% 
  select(meal) %>% 
  separate(meal, c("morning_meal","lunch_meal","dinner_meal"),
           sep="-", remove=FALSE) %>% 
  mutate(
    morning_meal = 
      str_remove(morning_meal,"割") %>% 
      str_trim() %>% 
      na_if("")
  ) %>% 
  mutate(
    lunch_meal = str_remove(lunch_meal,"割") %>% 
      str_trim() %>% 
      na_if("")
  ) %>% 
  mutate(
    dinner_meal = str_remove(dinner_meal,"割") %>% 
      str_trim() %>% 
      na_if("")
  )

#も分割することが可能です。
#次の動画で、これらをまとめて処理をしていきます。

## Lec: 看護記録もどきの加工3----------------

#まとめて処理をしていきましょう。、

wide3 <- wide2 %>% 
  #血圧
  separate(bp,c("am","pm"),sep="-") %>% 
  separate(am,c("am_sbp","am_dbp"), sep="/") %>% 
  separate(pm,c("pm_sbp","pm_dbp"), sep="/") %>%
  mutate(
    am_sbp = str_trim(am_sbp) %>% na_if(""),
    pm_sbp = na_if(pm_sbp,""),
  ) %>% 
  
  #脈拍
  separate(pulse,c("am_pulse","pm_pulse")) %>% 
  mutate(pm_pulse = na_if(pm_pulse,"")) %>% 
  
  #呼吸回数
  separate(rr,c("am_rr","pm_rr"),sep="-") %>% 
  mutate(
    am_rr = str_replace(am_rr,"回",""),
    pm_rr = 
      str_replace(pm_rr,"回","") %>% 
      str_trim() %>% 
      na_if("")
  ) %>% 

  #食事
  separate(meal, c("morning_meal","lunch_meal","dinner_meal"),
           sep="-") %>% 
  mutate(
    morning_meal = 
      str_remove(morning_meal,"割") %>% 
      str_trim() %>% 
      na_if("")
  ) %>% 
  mutate(
    lunch_meal = str_remove(lunch_meal,"割") %>% 
      str_trim() %>% 
      na_if("")
  ) %>% 
  mutate(
    dinner_meal = str_remove(dinner_meal,"割") %>% 
      str_trim() %>% 
      na_if("")
  )

View(wide3)

#これで全部わけることができました。
#ただし、amとpmがデータなので、これは縦にしておきましょう

long <- wide3 %>% 
  pivot_longer(cols=!c(name,date,admission),
               names_to = c("timing","sokutei"),
               values_to = "val",
               names_sep = "_") 

#valの値、数値型にしておきましょうただし、
long$val
as.numeric(long$val)

#何か、おかしい変換が起こっているみたいなので、

convert <- long %>% 
  select(val) %>% 
  mutate(val2 = as.numeric(val)) 

ng <- convert %>% filter(!is.na(val) & is.na(val2))
ng
#valは欠損していないのに、val2は欠損している
#ものを眺めると、こんな感じです。
#これだけだとなぜかわからないので、

ng$val

#こうすると、スペースが入っているように
#見えます。

long %>% 
  select(val) %>% 
  mutate(val2 = str_trim(val) %>% as.numeric()) 

#str_trimを変換前に挟むと警告はでてきませんでした
as.numeric("　16") #全角スペース
#が入っているとうまく変換できないみたいです。

#ということで、
long

long2 <- long %>% 
  mutate(val = str_trim(val) %>% as.numeric())

long2

#後は、
wide <- long2 %>% 
  pivot_wider(
    id_cols = c(name,date,admission, timing),
    names_from = sokutei,
    values_from = val
  )

View(wide)

meal_data <- wide %>% 
  select(name,date,admission,timing,meal) %>% 
  filter(!is.na(meal))

sokutei_data <- wide %>% 
  select(name, date, admission, timing, sbp, 
         dbp, pulse, rr) %>% 
  filter( str_detect(timing, "am|pm"))

#できました。


#とりあえず、こんな感じで加工できればセクション
#5の関数群は使いこなせていると思います！

#ここまでで、こんなデータが、
View(kiroku)

#こうなりました!
View(sokutei_data)
View(meal_data)

#いかがでしょうか?

#次は実際の厚生労働省のデータを加工してみましょう。

## Lec: 人口動態統計データの加工1-------------

#ここからは、data/mc360000.csvファイルのデータを加工して
#いきます。
#
#セクション5で解説した関数以外も少し登場します。
#このデータは、
#https://www.e-stat.go.jp/stat-search/files?page=1&layout=datalist&toukei=00450011&tstat=000001028897&cycle=7&year=20190&month=0&tclass1=000001053058&tclass2=000001053061&tclass3=000001053065&stat_infid=000031982775&result_back=1&tclass4val=0
#政府統計の総合窓口、
#自殺による死因（三桁基本分類）別にみた性・年次別死亡数及び百分率
#をダウンロードしたそのままのものです。
#
#一切エクセル等でデータの加工をすることなく、
#RのみでTidyにしていきましょう!

#まずはインポート!
#の前にデータを眺めましょう。
#RStudioでCSVファイルを開くと中身をテキストファイルとして見れます。
#
#まず、普通にひらくと文字化けしているので、
#File Reopenwith Encodingでshift-jisを選びましょう
#そうすると、最初の3行は注意書きになっており、これをインポートしてしまうとまずいです。

#ということで、文字コードはshift-jisで、最初の3行を飛ばしてインポートしましょう
#また、列名はあってないようなものなので、列名はつけない設定にしましょう

dat <- read_csv(
  file = "data/mc360000.csv", 
  locale=locale(encoding="shift-jis"),
  skip = 3, 
  col_names = FALSE
)

View(dat)

#X2列に総数が一番上にきていて、これは、ファイルの4行目の総数
#といっちしており、狙った行からインポートできています。
#
#ここで、ちょっと補足なのですが、
#skipの値はcol_namesで列名をTRUEとした場合とFALSEとした場合
#で同じ値を指定していても違う結果になります。

#例として、
use_shiftjis <- locale(encoding="shift-jis")

read_csv("data/skip.csv", locale=use_shiftjis)
read_csv("data/skip.csv", locale=use_shiftjis, skip=3)
read_csv("data/skip.csv", locale=use_shiftjis, skip=3, col_name=FALSE)

#行1 |
#行2 | skip=3 で行1から3までが飛ばされる
#行3 |
#行4  <- col_name=TRUEだとここが列名に
#行5  <- データはここからはじまる。
#行6

#行1 |
#行2 | skip=3 で行1から3までが飛ばされる
#行3 |
#行4  <- col_name=FALSEだとデータはここからはじまる
#行5  
#行6

#こんな感じです。
#さて、次の動画では、
dat
#の加工をつづけていきましょう。

## Lec: 人口動態統計データの加工2-------------

#ここでは、列名を作成することを考えます。
View(dat)

#データを眺めると、
#1行目　総数    NA    ... NA     NA   ...
#2行目　死亡数  NA    ... 百分率 NA   ...
#3行目　1995　　2000　... 1995   2000 ...

#と、こんな感じで、1行目から3行目までで合わせて列の
#ような形です。
#
#これを

#1行目　総数    総数   ...
#2行目　死亡数  死亡数 ...
#3行目　1995　　2000　 ...
#
#として、
# 総数_死亡数_1995 | 総数_死亡数_2000 | ...
# というような形の列名にすることができれば、
# pivot_longerで処理をまとめてできそうです。

#ここで1行ずつ抜き出してベクトルに変換しましょう。
#1行を抜き出すには、slice関数を利用するか、
#data[1,]
#の書き方を利用します

row1 <- dat %>% slice(1)
row1
row1 <- dat[1,]
row1

#それで、これをベクトルに変換したいのですが
#それは、as_vector()でできます

as_vector(row1)

#ということで、
row1 <- dat %>% slice(1) %>% as_vector()
row2 <- dat %>% slice(2) %>% as_vector()
row3 <- dat %>% slice(3) %>% as_vector()

dat_colname <- tibble(
  r1 = row1,
  r2 = row2,
  r3 = row3
)

dat_colname



#このデータから列名をつくります。
#まず、欠損値をうめます。

dat_colname <- dat_colname %>% 
  fill(r1,r2,r3,.direction="down")

dat_colname
#そして、separate関数の反対の動作をする関数があるのでそれを利用
#していましょう。uniteです。

dat_colname2 <- dat_colname %>% 
  unite(col = "coln", r1, r2, r3,sep="_", remove=FALSE)

View(dat_colname2)

#この作成したcoln列をベクトルとしてとりだして、
#datの列名にしてあげればよいです

#ベクトルとして列を取り出す場合は、pull()を使います。
#また、setNames関数で文字ベクトルを一括して表の
#列名にしていできます。

vec_coln <- dat_colname2 %>% 
  pull(coln)

vec_coln

dat

#ちょうど、
length(vec_coln)
ncol(dat)

#ベクトルの長さと列数が一致していますね?
dat2 <- dat %>% setNames(vec_coln)

View(dat2)

#うまくいきました。これで、最初の3行は必要ないので、
#消しましょう。あと、4行目、X60-X84 総数 に該当する行の消しておきます
#(個別のデータのみにしたい状況としておきまｓ)
#slice関数は、中の数字に―をつけると削除するという意味になる
#ので、

dat3 <- dat2 %>% 
  slice(-(1:4))

View(dat3)

#いかがでしょうか?
#
#NA_NA_NAという列名はきになるので適当に変えておきましょう

dat4 <- dat3 %>% 
  rename(cause = NA_NA_NA)

View(dat4)

## Lec: 人口動態統計データの加工3-------------

#もう少しです。cause列、[X数字　説明]という
#形になっているため、これは二つに分けておきます。

#区切られている文字をしらべてきます

str_view_all(dat4$cause[1:3]," ")
str_view_all(dat4$cause[1:3],"　")

#どうやら全角文字のようなので、
dat5 <- dat4 %>% 
  separate(cause, c("id","name"), sep="　+")
  
View(dat5)

#準備がととのいました!

dat6 <- dat5 %>% 
  pivot_longer(
    cols = !c(id,name),
    names_to = c("sex","type","year"),
    values_to = "val",
    names_sep = "_"
  )

View(dat6)

#ほとんどtidyです

str(dat6)

#yearとvalを数値型に変換しておきましょう。
#また、valは未測定は「-」で記入されているので
#そこは欠損値にしておきます（わざわざ変換しなくても、
#NAに-は勝手におきかわりますが、警告がでるのも
#気持ち悪いので手動で変換しておきましょう。）

dat7 <- dat6 %>% 
  mutate(year = as.numeric(year),
          val = val %>% na_if("-") %>% as.numeric())

View(dat7)

#総数がsexに含まれているは気持ち悪いのでこれも消して
#おきましょう。

dat8 <- dat7 %>% 
  filter(sex != "総数")

#以上、ここまでの処理で、

View(dat)

#が、

View(dat7)

#になった結果、
gdat <- dat8 %>% 
  filter(type == "死亡数") %>% 
  filter(id == "X60")
title <- gdat$name[1]

ggplot(gdat) + 
  geom_col(aes(x = year, y = val, fill = sex)) +
  facet_wrap(~sex) +
  labs(title = title)

#と、こんな感じでグラフを簡単に描画できました。

#他にもdistinct関数を利用すると

dat8 %>% 
  select(id, name) %>% 
  distinct()

#こんな感じで集計することができます。
#薬剤関係でX60,X61,X62,X63の4つのidを
#絞り込んで描画するのであれば、

gdat <- dat8 %>% 
  filter(type == "死亡数") %>% 
  filter(id %in% c("X60","X61","X62","X63"))

ggplot(gdat) +
  geom_col(aes(x = year, y = val, fill = sex)) +
  facet_wrap(~name)

#というグラフを作成することもできます。
#尚、　%in%　という表記をはじめて利用しましたが、

c(1,2,3, 1, 2, 3, 4, 5, 1) %in% c(2, 4)

#こんな感じで、左側のベクトルに対して、右側のベクトル
#に含まれているかそうでないかという
#条件でロジカルベクトルを作成することができます。

#これを、filterの中で利用すれば、
#複数の条件で絞り込むことが簡単にできます。

#次はここで学んだ智識を使って、食中毒データの
#処理を行いましょう。


## Lec: 食中毒データの加工1-------------

#ここでは、
#data/food_poisoning2020.xls
#の、④病因物質別発生状況
#
#シートからデータをインポートして
#tidyデータにしていきます。
#
#もし可能そうであれば一度解説を見る前
#に取り組んでみてください。なお、総数等
#の集計されたデータはすべて破棄する形で
#進めましょう。

#それではいきます!

#まずはデータを眺めてみます。
#3-36行目に1-6月のデータ(A3:W36)
#
#39-72行目に7-12月のデータ(A39:T72)
#
#が含まれています。
#read_excel関数のヘルプファイルを見ると、
#rangeアーギュメントがあり、範囲指定でデータ
#を取得することができます。
#なので、

dat_a <- read_excel("data/food_poisoning2020.xls",
                    range = "A3:W36",
                    col_names = FALSE,
                    sheet="④病因物質別発生状況")

dat_b <- read_excel("data/food_poisoning2020.xls",
                    range = "A39:T72",
                    col_names = FALSE,
                    sheet="④病因物質別発生状況")

View(dat_a)
View(dat_b)

#まずdat_aから処理しましょう。
#1行目と2行目に列名となりうる行です。
#人口動態データの処理にならって列名を作成しましょう。

row1 <- dat_a %>% slice(1) %>% as_vector()
row2 <- dat_a %>% slice(2) %>% as_vector()

col_a <- tibble(r1 = row1, r2 = row2) %>% 
  fill(r1, r2) %>% 
  replace_na(list(r2="")) %>% 
  unite("col_a",r1, r2, sep="_")

#ここでcol_aの列名が1行目と2行目で同じ値です。
#データを確認すると、1行目と2行目はそれぞれ、
#分類1、分類2という形で分かれているとみなせる
#ので、それを反映しておきましょう。

col_a$col_a[1] <- "cause_1"
col_a$col_a[2] <- "cause_2"

col_a

dat_a2 <- dat_a %>% 
  setNames(col_a$col_a) %>% 
  slice(-c(1:2))

View(dat_a2)

#cause_1をまずは埋めましょう。ついで、
#総数を表すことになるので、cause_2が欠損している
#行は削除します。

dat_a3 <- dat_a2 %>% 
  fill(cause_1) %>% 
  filter(!is.na(cause_2))

#縦持ちに変換します。

dat_a4 <- dat_a3 %>% 
  pivot_longer(
    cols = !c(cause_1, cause_2),
    names_to = c("month","type"),
    values_to = "val",
    names_sep = "_"
  )

View(dat_a4)

#総数を削除します
dat_a5 <- dat_a4 %>% 
  filter(month != "総数")

View(dat_a5)

#縦持ちデータに変換できました!
#ここで、同じ変換を

dat_b

#にも適応しましょう。
#練習がてら、dat_bにも適応してみてください。

#dat_aの処理は、中間の変数を削除して記載すると、

row1 <- dat_a %>% slice(1) %>% as_vector()
row2 <- dat_a %>% slice(2) %>% as_vector()

col_a <- tibble(r1 = row1, r2 = row2) %>% 
  fill(r1, r2) %>% 
  replace_na(list(r2="")) %>% 
  unite("col_a",r1, r2, sep="_")

col_a$col_a[1] <- "cause_1"
col_a$col_a[2] <- "cause_2"

dat_a2 <- dat_a %>% 
  setNames(col_a$col_a) %>% 
  slice(-c(1:2)) %>% 
  fill(cause_1) %>% 
  filter(!is.na(cause_2)) %>% 
  pivot_longer(
    cols = !c(cause_1, cause_2),
    names_to = c("month","type"),
    values_to = "val",
    names_sep = "_"
  ) %>% 
  filter(month != "総数")

#こんな感じです。
#これを参考にして、dat_bに適応すると、

row1 <- dat_b %>% slice(1) %>% as_vector()
row2 <- dat_b %>% slice(2) %>% as_vector()

col_b <- tibble(r1 = row1, r2 = row2) %>% 
  fill(r1, r2) %>% 
  replace_na(list(r2="")) %>% 
  unite("col_b",r1, r2, sep="_")

col_b$col_b[1] <- "cause_1"
col_b$col_b[2] <- "cause_2"

dat_b2 <- dat_b %>% 
  setNames(col_b$col_b) %>% 
  slice(-c(1:2)) %>% 
  fill(cause_1) %>% 
  filter(!is.na(cause_2)) %>% 
  pivot_longer(
    cols = !c(cause_1, cause_2),
    names_to = c("month","type"),
    values_to = "val",
    names_sep = "_"
  ) %>% 
  filter(month != "総数")

dat_a2
dat_b2

#できあがりました。
#次の動画でデータを結合しましょう。

## Lec: 食中毒データの加工2-------------

#ひとつ前の動画で作成した二つのデータ、
#結合しましょう。
#
#ここでの結合は二つのデータの列同士を
#結合するやり方になり、join系の関数を利用しません。

#join系の関数は、
#
# A  <- A
# B  <- B
# C  <- C
# こうですが、
# 
# ここで行いたい結合は、
# A
# B
# C
# A
# B
# C
# 
# という縦方向の結合です。
# この結合を行うのは、

test1 <- tibble(A = c(1:3), B = c(11:13))
test2 <- tibble(A = c(4:6), B = c(14:16))

test1
test2
bind_rows(test1, test2)

#この、bind_rows関数です。
#ということで、

dat_fin <- bind_rows(dat_a2, dat_b2)

View(dat_fin)

#くっつきました。
#後は、cause_1とcause_2の余分な空白、

dat_fin$cause_1 %>% unique()
dat_fin$cause_2 %>% unique()

#を削除しておきましょう。

str_view_all( unique(dat_fin$cause_1), "　")
str_view_all( unique(dat_fin$cause_2), "　")

dat_fin <- dat_fin %>% 
  mutate(
    cause_1 = str_remove_all(cause_1,"　"),
    cause_2 = str_remove_all(cause_2,"　")
  )

#また、valは、「-」が欠損値として利用
#されているので置き換えておきましょう。

dat_fin <- dat_fin %>% 
  mutate(val = na_if(val,"-")) %>% 
  mutate(val = as.numeric(val))

View(dat_fin)

#以上！キレイな形になりました。
#
#グラフ化してみましょう。

gdat <- dat_fin %>% 
  filter(cause_2 == "ノロウイルス") 

ggplot(gdat) + 
  geom_col(aes(x = month, y = val)) +
  facet_wrap(~type)

#monthの並びが10月、11月、12月、1月と並んでいる
#のでここの並びを整えましょう。

#因子型にすると並びを調整することが可能です。

month_label <- c("1月","2月","3月","4月","5月","6月",
                 "7月","8月","9月","10月","11月","12月")

dat_fin <- dat_fin %>% 
  mutate(month = factor(month,
                        levels=month_label,
                        labels=month_label))

gdat <- dat_fin %>% 
  filter(cause_2 == "ノロウイルス") 

ggplot(gdat) + 
  geom_col(aes(x = month, y = val)) +
  facet_wrap(~type)

#うまくならびましたね！

#以上、実際のデータをインポート、加工してグラフ
#化する一連の流れをみてみました。
#
#解説しながらなので、スクリプト量が
#多く感じるかもしれませんが、
#後から解説する「関数化」を利用すれば、
#同じ形のデータを1行で処理できたりするので、
#引き続きお付き合いください。

#おつかれさまでした。
#ここまでの加工ができるようになれば、
#思いどおりにデータの形を変形することが
#できるようになっているはずです。
#データのインポート、可視化、データ加工の
#3つの手順をストレスなくできるようになれば、
#あなたが行いたいデータ分析はほぼ
#8割が終了しているという格言もあったりします。

#残りのセクションで、
#　・統計的モデリングを解説しながらR言語で
#　　　数式の計算を行う方法。
#　
#　・データの集計を行う方法
#　
#　・分析結果を共有するときに有用な
#　　　レポート作成の知識をお伝えいたします。
