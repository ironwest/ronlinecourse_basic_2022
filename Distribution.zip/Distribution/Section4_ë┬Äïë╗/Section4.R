## Section4: 可視化----------------------------

## Lec: セクションの全体像--------------------

# slide 1-7

## Lec: graphics:関数を使ってグラフを描画する--------

#まず、この動画では、Rに最初から含まれている
#graphicsパッケージを利用して、関数を使って
#グラフを描画することを経験しましょう。
#
#また、graphicsパッケージは「さっと」可視化する
#のに便利な機能なので、ここでご紹介する関数を覚えて
#置くと、将来役立つかもしれません。

#まずは、数字の推移を確認したいような場合
vec <- c(1,3,5,4,3,
         6,7,4,3,2,
         5,6,7,9,10,
         4,5,8,4,11,
         13,12,15,12,11,
         14,9,12)

plot(vec)

#どうでしょうか？plot関数に数字を含むベクトルを与えて
#あげるだけで、こんなグラフが描画できました！

#また、例えばvecに入っているのが、アイスクリームが売れた数だと
#して、

hiduke <- c(1:28)

graphics::barplot(vec, names.arg=hiduke)

#x軸に日付を表示したり
weekend <- rep(
  c(rep("平日",5),"週末","週末"), 4
)

weekend

barplot(vec, names.arg=hiduke, col=as.factor(weekend))

#平日、週末を色分けしたりすることができます。
#このようにベクトルをグラフ表示をする関数に与えて
#あげると、グラフをうまく描いてくれるという
#イメージをここでしっかりと押さえておいてください

#他にも,例としては
#dotchart:
dotchart(log(islands, 10),
         main = "islands data: log10(area) (log10(sq. miles))")
dotchart(log(islands[order(islands)], 10),
         main = "islands data: log10(area) (log10(sq. miles))")

#hist:
hist(islands)
hist(sqrt(islands), breaks = 12, col = "lightblue", border = "pink")

#boxplot:
boxplot(count ~ spray, data = InsectSprays, col = "lightgray")

boxplot(decrease ~ treatment, data = OrchardSprays, col = "bisque",
        log = "y")

#等、graphicsパッケージの各関数を利用すると、
#こんな感じでグラフを描くことができます
#
#(ここでお見せしたのは、ヘルプファイルの例の内容となります
#現時点では、この内容を理解している必要はありませんし、
#単純に、関数でグラフがかけるということを知っていただければ
#この動画の目的は達成しています。)
#
#それでは次の動画からは、メインであるggplotを利用した
#グラフの作成方法を解説していきます

##Lec:ggplot2の導入------------------------

library(ggplot2)
library(tidyverse)
ggplot(mpg)+geom_point(aes(x=cty,y=hwy))

ggplot(data = mpg) +
  geom_point(mapping = aes(x=cty, y=hwy, color=as.factor(cyl))) +
  labs(title = "自動車の燃費", x = "街乗り[マイル/ガロン]", y = "高速") +
  scale_color_discrete(name="シリンダー数") +  
  theme_minimal() +
  theme(legend.box.margin = margin(0,-50,0,0))

##Lec: 因子型:解説------------------------

#Slide 23-32

##Lec: 因子型:data.frame関数-----------------------------
#
#それでは、スライドでお伝えしたことを実際にRで動かして
#見ていきましょう。
library(tidyverse)

#まずは文字列型のベクトルを作成しましょう。
alcohol = c("週1日以内","週4-6日","週4-6日","毎日","のまない","週1-3日","毎日")

str(alcohol)

#このベクトルに含まれているものは文字列ですね？
#文字列を利用して表を作成した場合に、
#実はdata.frameとtibbleでは結果が違ってきます。
#
#やってみましょう、

dat_df <- data.frame(alcohol=alcohol)
dat_ti <- tibble(alcohol=alcohol)

str(dat_df)
str(dat_ti)

#str関数で、作成したそれぞれの表の型をみてみると、
#data.frameの方はalcohol列がFactorと表示されている
#一方、tibbleの方はchrと表示されています。

#実は、data.frameで作成した表は、文字列が勝手に
#因子に置き換わってしまっています

#すこしヘルプファイルを見てみましょう

?data.frame

#Usageの中の、stringsAsFactorsという設定が
#default.stringsAsFactors()となっており

default.stringsAsFactors()

#TRUEになっています。

#strings(文字列)As(を)Factors(因子に)という
#オプションがTRUEになっているため、
#data.frame関数は勝手に文字列を因子型に
#変換してしまいます。

#この挙動、知らないと困るのは、例えば、間違って
#数値型に列を変換してしまったときに、

str(alcohol)

as.numeric(alcohol)

#文字列型であれば
#数値型に変換できずエラーがでてしまうのですが、
#先のスライドでも解説したように、因子型は
#実態が数字とその対応表という形で保たれている
#イメージなので、

as.numeric(dat_df$alcohol)

#数字型に変換できてしまいます！
#この挙動、便利な反面、こまることが多いので、
#data.frame型を利用する場合は、

dat_df2 <- data.frame(
  alcohol=alcohol, 
  stringsAsFactors = FALSE
)

str(dat_df2)

#このように、stringAsFactorsのアーギュメントを
#FALSEとして作成する癖づけておくとよいと
#思います。

#tibble形式はこのようにかってに型を
#置き換えて表を作成したりはしないので、
#この設定を気にする必要はありません。
#このレクチャー以降は、原則tibbleで
#表を作成していきます。
#
#それでは、次の動画では因子型を作成する方法について
#解説していきます。

## Lec: 因子型をas.factorで作成する-----------------

#それでは、ここでは因子型を作成していきます。
#まずは、1つ前の動画で作成したalcohol
#変数を変換してみましょう。
#
#とはいっても、スライドで解説した通り、
alcohol = c("週1日以内","週4-6日","週4-6日","毎日","のまない","週1-3日","毎日")
as.factor(alcohol)

#としてあげるだけです。
#実行結果をみると含まれるデータの表示のあとに、
#
#5 Levels: のまない 週1-3日 週1日以内 ... 毎日
#
#となっています。

vec_f <- as.factor(alcohol)

#因子型に変更した時点で、

as.numeric(alcohol)
as.character(alcohol)

as.numeric(vec_f) 
as.character(vec_f)

#で変換される挙動が文字列型とは
#ちがってきていますね？

#スライドで解説した、対応表というのは、

levels(vec_f)

#Levelsという関数でみることができるため、
#実行結果の一つ目が数字の1に対応して、
#全部で5levelあるような形になっています。

#次の動画では、この水準を手動で置き換える
#方法について解説していきます。

## Lec: 因子型のレベルを置き換える-------------

#それでは、因子型の水準を手動で置き換えていきましょう

levels(vec_f)

#は実行すると、水準を表示してくれますが、

levels(vec_f) <- c("いち","に","さん","し","ご")

levels(vec_f)

#このように、代入してあげると、対応表を与えた
#文字列で置き換える使い方も可能です。

vec_f

#置き換えた結果が反映されていますね?

vec1 <- as.factor(alcohol)

vec2 <- vec1
levels(vec2) <- c("いち","に","さん","し","ご")

vec1
vec2

as.numeric(vec1)
as.numeric(vec2)

#レベルを置き換えた後、数字型にするとvec1とvec2は
#一致していますが、

as.character(vec1)
as.character(vec2)

#文字列型に置き換えると、このように結果が変わっている
#ということを確認しておいてください。

#それで、この置き換えですが、一部だけを置き換える
#ことも可能です。

#その場合、[]での位置指定を行ってあげると
#比較的簡単に狙った場所の値を置き換えられます。
#
#[]は、

c("いち","に","さん","し","ご")[1]
c("いち","に","さん","し","ご")[2]
c("いち","に","さん","し","ご")[3]
c("いち","に","さん","し","ご")[4]
c("いち","に","さん","し","ご")[5]

#このように、ベクトルの後に、数字を入れて
#指定してあげることでその場所の要素を
#取り出すことができます。また
#変数に対しては代入も可能なので

c("いち","に","さん","し","ご")[1] <- "ONE"

#これはだめですが、
temp <- c("いち","に","さん","し","ご")
temp[1] <- "ONE"
temp

#こんな風に、置き換えることができました!
#
#レベルも同様に、

vec2

levels(vec2)[4] <- "Four!"

vec2

#置き換えることができました。

#また、複数同時に置き換えたい場合は、

temp[c(2,5)]

#で別々の場所を指定できるので、

temp
temp[c(2,4)] <- c("TWO","FOUR")
temp

#を利用して、

vec2
levels(vec2)[c(2,5)] <- c("Two","Five")
vec2

#とすることが可能ですし、
#因子型にレベルを追加したい場合は、

temp
temp <- c(temp,"ろく","なな")
temp

#を利用して、

vec2
levels(vec2) <- c(levels(vec2), "Six","Seven")
levels(vec2)
vec2

#としてあげるとよいです。
#ちょっと最後は駆け足でしたが、現時点
#では、
#　位置を狙って複数置き換えられる
#　レベルを追加することもできる
#ということを覚えていただいておく程度
#で問題ありません。
#次は因子型の対応表も指定して作成する方法
#を解説いたします。

##Lec:因子型を手動で作成してみる-------------------
#ここまでは、as.factorで因子型を作成したり、
#作成されたレベルを変更する方法について解説
#してきましたが、ここでは、factor関数を利用して
#対応表を含めて最初から作成する
#方法について解説しておきます。

alcohol = c("週1日以内","週4-6日","週4-6日","毎日","のまない","週1-3日","毎日")

?factor

#ここで最低限必要となるのはアーギュメントに
#初期値が設定されていないlevelsです。

#対応表を作成するためにはlevelsとlabelsの二つが、
#必要となります。複数形でsがついているの
#注意しておいてください。

#例えば、1で男性、2で女性を表すようなデータ
#があったとして、因子型を作成したい場合は

factor(
  c("1","2","1","1"), 
  levels=c("1" ,"2"),
  labels=c("男","女")
)

#としてあげることで作成できます。
#levelsに与えてあげるベクトルに記載されている
#そのままの、レベルにしたい値を与えて、
#labelsに与えてあげたレベルの順番で、
#文字として表示したいベクトルを与えてあげる
#形になります。
#
#ここで、levelsやlabelsの挙動も確認しておきましょう

#例えば、今度はペットの種類を聞いているような
#データだとすると、

factor(
  c("1","2","1","1","2"), 
  levels=c("1" ,"2","3"),
  labels=c("犬","猫","ペットはいない")
)

#このようにlevelsを増やしても問題はありません。
#単純にレベルとしてはあっても、答えた人が
#いなかったようなケースではこういうことは
#起こりえます

factor(
  c("1","2","1","1","2"), 
  levels=c("1" ,"2"),
  labels=c("犬","猫","ペットはいない")
)

#ただし、ラベルのベクトルの長さとレベルの
#ベクトルの長さは一致していないとエラーになります
#ので注意してください。(対応表という意味では
#あたりまえといえばあたりまえの動作ですね！)

#レベルが増えても、同じように対応できます。
factor(
  c("1","2","1","1","2","4","4","5","3"), 
  levels=c("1" ,"2","3","4","5"),
  labels=c("犬","猫","ハムスター","金魚","カブトムシ")
)

#いかがでしょうか?
#因子型、作成できそうですか?
#次の動画でここまでで学んだ知識をつかって因子型を
#作成する課題をご提示して回答いたしますので、
#とりくんでみてください。


##Lec:因子型課題----------------------------

#それでは復習しておきましょう。
#
#課題1:次のベクトル(vec)を因子型に変換して、
#適当な名前の名前の変数を作成してください

vec <- c("大阪","京都","大阪","兵庫","京都")

#課題2:課題1で作成した因子型の変数のレベルを
#確認してください

#課題3:課題1で作成した因子型の変数のレベルを大阪府、
#京都府、兵庫県のように、府県を付けた形に直して
#ください。

#課題4:課題3で修正した因子型ベクトルのレベルに、
#奈良県、和歌山県、滋賀県を追加してください。

#課題5:次のvec2ベクトルを
#a: 大阪府
#b: 京都府
#c: 兵庫県
#d: 和歌山県
#e: 奈良県
#f: 滋賀県
#となるように、factor関数を利用して、因子型
#ベクトルを作成してください。

vec2 <- c("a","b","d","a","b","e","c")

#動画を止めて、解答を作成してみてください。
#パソコンを開いていないという方は、
#頭のなかでどのようなスクリプトを書くか、
#考えてみてください。







#できましたか？

#課題1:次のベクトル(vec)を因子型に変換して、
#適当な名前の名前の変数を作成してください

vec <- c("大阪","京都","大阪","兵庫","京都")

fac <- as.factor(vec)

#課題2:課題1で作成した因子型の変数のレベルを
#確認してください

levels(fac)

#課題3:課題1で作成した因子型の変数のレベルを大阪府、
#京都府、兵庫県のように、府県を付けた形に直して
#ください。

levels(fac) <- c("京都府","大阪府","兵庫県")
levels(fac)
fac

#課題4:課題3で修正した因子型ベクトルのレベルに、
#奈良県、和歌山県、滋賀県を追加してください。

levels(fac) <- c(levels(fac), "奈良県","和歌山県","滋賀県")
levels(fac)
fac

#課題5:次のvec2ベクトルを
#a: 大阪府
#b: 京都府
#c: 兵庫県
#d: 和歌山県
#e: 奈良県
#f: 滋賀県
#となるように、factor関数を利用して、因子型
#ベクトルを作成してください。

vec2 <- c("a","b","d","a","b","e","c")
factor(
  vec2,
  levels=c("a","b","c","d","e","f"),
  labels=c("大阪府","京都府","兵庫県",
           "和歌山県","奈良県","滋賀県")
)

#以上です！
#それでは次からグラフの作成に入っていきましょう。

## Lec: ggplot2でのグラフ作成基礎:geom関数群----------

#Slide:33-40

## Lec: ggplot2でのグラフ作成基礎:軸の設定方法----------

#Slide 41-58

## Lec: ggplot2でのグラフ作成基礎:軸の設定方法(演習問題)-----------------

#この動画では、ggplot2を用いて、グラフを描画する
#方法について、ここまで解説した知識を用いて演習問題
#を解いていきます。

#まずパッケージを読み込んでおきましょう
library(ggplot2)
#あるいは
library(tidyverse)

#これで、
diamonds
economics
msleep

#等のデータセットが利用できるように
#なっていると思うので、
#これらを利用します。

#補足しておくと、
?diamonds
#diamonds：50000個のダイヤモンドのデータ
# price -> 値段(ドル)
# carat -> 重さ
# cut -> カットの質（カテゴリカル変数）
# color -> ダイヤの色（カテゴリカル変数、
#　　　　Jが最低、Dが最高）
# clarity -> ダイヤの透明度
#　　　　　　（悪い：I1 SI2 SI1 VS2 VS1 
#              VVS2 VVS1 IF 最高。
#            カテゴリカル変数
# x, y, z -> 長さ、幅、
#            深さをミリメートル単位

#他のデータセットも、helpの検索を利用すれば
#詳しい内容を知ることができます。

?economics
?msleep

#では、出題していきます。
#まず例題を一緒にやりましょう。
#
#例題：ダイヤモンドの長さ(x)と幅(y)の関係を
#       散布図で描画してください。

#この例題では、利用するデータはdiamonds,
#軸に利用する変数は、それぞれxとyです。
#描画するグラフは散布図のため、使用する
#geom関数群の関数はgeom_pointになります。
#これらをすべて盛り込んだスクリプトは、

ggplot(data = diamonds) +
  geom_point(mapping=aes(x=x, y=y))

#どうでしょうか?うまく描画できましたか?
#たまにある外れ値を除いて直線関係にありそうな
#グラフですね。
#
#それでは、今の要領で、次の問題Q1-Q6まで
#解いてみてください。
#次の動画で答えを解説いたします。

#Q1: ダイヤモンドの重さと値段の関係を、
#    散布図で描画してください。
#Q2: ダイヤモンドの色と値段の関係を、
#    箱ひげ図で描画してください。
#Q3: ダイヤモンドの透明度と色の関係を、
#    何らかの形で描画してください
#Q4: ダイヤモンドの値段の分布をヒストグラムにして
#    描画してください
#Q5: ダイヤモンドのカットの質が分類毎に、
#    このデータセットに何件ずつあるのかを
#    描画してください。
#Q6: この問題には、economicsデータを利用します。
#    米国の失業者数の推移を何らかの形で描画してください。

#economics:米国の経済データ
# date -> 日付
# unemploy -> 失業者数（千人単位）
# pop -> 人口（千人単位）

## Lec: ggplot2でのグラフ作成基礎:軸の設定方法(解答)-----------------

#それでは、1つ前の動画で出題した
#問題を解説していきます。

#Q1: ダイヤモンドの重さと値段の関係を、
#散布図で描画してください。

#データ:diamonds
#geom:geom_point
#  ->x軸:carat　
#  ->y軸:price

ggplot(data = diamonds) + 
  geom_point(mapping = aes(x = carat, y = price))

#Q2: ダイヤモンドの色と値段の関係を、
#箱ひげ図で描画してください。

#データ:diamonds
#geom:geom_boxplot
#  ->x軸:color　
#  ->y軸:price

ggplot(data =diamonds) +
  geom_boxplot(mapping = aes(x = color, y = price))

#Q3:　ダイヤモンドの透明度と色の関係を、
#何らかの形で描画してください

#データ:diamonds
#geom: ???
#  ->x軸:clarity　
#  ->y軸:color

#ここでは、x軸とy軸がそれぞれカテゴリカル変数
#なので、これまでお伝えした関数の中で利用できる
#geomはgeom_countです。

gdia <- ggplot(data = diamonds)
gdia + geom_count(aes(clarity, color))

#他にも、カテゴリカル×カテゴリカルで利用できる
#geomは、geom_jitterというものがあり、

gdia + geom_jitter(aes(clarity, color))

#こんな感じで、gdiaという変数を作っておくと、
#別のgeomを適応する場合も、それほど手間なく
#描画できます。
#
#今回、jitterが見やすいとは思いませんが、
#それぞれのカテゴリに含まれる数がそれほど
#多くない場合に、どれくらいのデータの個数が
#含まれているかを直観的に把握できるので、
#覚えておいてもよいかもしれません。


#Q4: ダイヤモンドの値段の分布を
#ヒストグラムにして描画してください

#データ:diamonds
#geom: geom_histogram
#  ->x軸:price
#  ->y軸:集計

gdia + geom_histogram(aes(price))

# Argumentから全部書き出すとこんな感じです:
ggplot(data = diamonds) + 
  geom_histogram(mapping = aes(x = price))

#Q5: ダイヤモンドのカットの質が分類毎に、
#このデータセットに
#何件ずつあるのかを描画してください。

#データ:diamonds
#geom:geom_bar
#  ->x軸:cut　
#  ->y軸:集計

gdia + geom_bar(aes(cut))
summary(diamonds$cut)

#直接集計結果をsummary関数などで見た方が
#正確な数字わかりますが、geom_bar関数で
#集計されていること、みていただけるかと思います。

#Q6: この問題には、economicsデータを利用します。
#米国の失業者数の推移を何らかの形で描画してください。

#データ:economics
#geom:???
#  ->x軸:date　
#  ->y軸:unemploy

#ここでは、x軸はdateという日付型の変数です。
#日付型の変数はまだ解説していませんが、
#現時点では連続変数の一種であるというような理解で
#OKです。

#推移を表現するので、利用できるgeomには
#geom_line等を使ってみましょう。

economics
g_eco <- ggplot(economics) 
  
g_eco + geom_line(aes(date, unemploy))

#他にも、点を打つだけでも大丈夫かもしれません
g_eco + geom_point(aes(date, unemploy))

#以上、ggplot+geom_xxxの基本的な形の
#解説と演習でした。
#
#次の動画からは第3、第4の軸、色や形の設定などについて解説
#していきます。

## Lec: ggplot2でのグラフ作成基礎:色と形の設定-----------------

#slide:59-67

## Lec: ggplot2でのグラフ作成基礎:色と形の設定(実践)-----------------

#ここからは、スライドで解説したcolor, shape, fill
#等を利用してグラフに色や形を設定していく過程を
#確認していきましょう

library(tidyverse)

#ひとつ前のトピックの課題からスタートします。
#
#Q1: ダイヤモンドの重さと値段の関係を、
#散布図で描画してください。

ggplot(data = diamonds) + 
  geom_point(mapping = aes(x = carat, y = price))

#これだけだと、ただのなんとなく右肩上がりの
#グラフです。ここで、同じ重さでも、値段に開きが
#ありそうなことが見て取れます。

#ここで、この値段の開きがカットに影響されている
#と考えると、
ggplot(data = diamonds) + 
  geom_point(
    mapping = aes(x = carat, y = price, color = cut)
  )

#こんな感じのグラフになりました。
#また、

# ダイヤモンドの透明度はどうでしょうか?
ggplot(data = diamonds) +
  geom_point(
    mapping = aes(x = carat,y = price, color = clarity)
  )

#なんか意味ありそうですね。　色もみて見ましょう
ggplot(data = diamonds) + 
  geom_point(
    mapping = aes(x = carat,y = price,color = color)
  )
#こっちも関係ありそうですね。

#ここで、ちょっと補足です

#slide 69
# >このように、実はdataとmappingは
# ggplotの中においてもOKですし、
# geom関数の中においても大丈夫です。
# >mappingは、＋以降のgeom関数に
# その効果は続きます。　（Scriptへ）

#なので、うえの例のようにほぼ同じグラフを
#たくさん書いて探索的なデータ可視化を行う場合は、
#次のように書いてもOKです

gg <- ggplot(
  data = diamonds, 
  mapping = aes(x = carat,y = price)
)

gg + geom_point()
gg + geom_point(mapping = aes(color = cut))
gg + geom_point(mapping = aes(color = clarity))

#さらに、argumentが指定されていない場合、
#ヘルプファイルの順番
#通りに記載されていると解釈されるため、
#data= mapping=部分は
#省略できるため、

gg <- ggplot(diamonds, aes(carat, price))
gg + geom_point()
gg + geom_point(aes(color = cut))

#という風に簡略できます。


#Q2: ダイヤモンドの色と値段の関係を、
#箱ひげ図で描画してください。
library(ggplot2)

ggplot(data =diamonds) +
  geom_boxplot(mapping = aes(x = color, y = price))

#これも、色と値段に何かしらの関係がありそうです。
#他の変数で色分けしてみましょう
ggplot(data = diamonds) +
    geom_boxplot(mapping = aes(x = color, 
                               y = price, 
                               color = cut))
 
ggplot(data = diamonds) +
   geom_boxplot(mapping = aes(x = color,
                              y = price,
                              color = clarity))
 

#colorでなくてfillを使うと、
ggplot(data = diamonds) +
  geom_boxplot(mapping = aes(x = color, 
                             y = price, 
                             fill = cut))

ggplot(data = diamonds) +
  geom_boxplot(mapping = aes(x = color,
                             y = price,
                             fill = clarity))

#colorとfillの違い、OKですね。
#colorは箱ひげ図の線に色を規定して、
#fillは中身に色を設定します。

#もちろん、両方使うことも可能で、
ggplot(data = diamonds) +
  geom_boxplot(mapping = aes(x = color,
                             y = price,
                             fill = clarity,
                             color = clarity))

#ここまでのグラフ、なるべく省略して
#かくとすると、
#こんな感じです。

gg <- ggplot(diamonds, aes(color, price))

gg + geom_boxplot(aes(color=cut))
gg + geom_boxplot(aes(color=clarity))

gg + geom_boxplot(aes(fill=cut))
gg + geom_boxplot(aes(fill=clarity))

gg + geom_boxplot(aes(fill=clarity, color = clarity))

             
             
#Q3:　ダイヤモンドの透明度と色の関係を、
#何らかの形で描画してください

#ここからは全部省略して書いていきます。
gdia <- ggplot(data = diamonds)

gdia + geom_count(aes(clarity, color))
gdia + geom_jitter(aes(clarity, color))

#
gdia + geom_jitter(aes(clarity, color, color = cut))
gdia + geom_jitter(aes(clarity, color, color = clarity))
   #意味ないですけど
gdia + geom_count(aes(clarity, color, color = cut))


gdia + geom_jitter(aes(clarity, color, color = carat)) 
　 #このように、連続変数も色の濃さで表現されます

#Q4: ダイヤモンドの値段の分布をヒストグラムにして
#描画してください
gdia <- ggplot(data = diamonds)

gdia + geom_histogram(aes(price))

gdia + geom_histogram(aes(price, color = cut)) #???
gdia + geom_histogram(aes(price, fill = cut))
gdia + geom_histogram(aes(price, fill = clarity))

#Q5: ダイヤモンドのカットの質が分類毎に、
#このデータセットに何件ずつあるのかを描画してください。
gdia + geom_bar(aes(cut))

gdia + geom_bar(aes(cut, fill = clarity))

gdia + geom_bar(aes(cut, fill = clarity))　
  #これを種類毎に分けたい場合はどうすればいでしょうか？
#positionというオプションがあるgeom_XXXでは、

#次のようなことができます。
gdia + geom_bar(mapping = aes(cut, fill=clarity), 
                position = "dodge")　
　　　#dodgeはよけるという意味です。
gdia + geom_bar(aes(cut, fill=clarity),
                position = "stack")

#Q4のヒストグラムも同様です。
gdia + geom_histogram(aes(price, fill = clarity), 
                      position = "dodge")

#のようなことも可能です。
#
#色分けの設定、colorとfillの使い分けについて
#理解できましたでしょうか?
#後は形について確認しておきましょう。
#
#diamondsデータだと件数が多くて、
#形でのデータの区分には不都合なので、ここからは
#msleepデータを利用して解説していきます。

#脳の重量をx軸、睡眠時間をy軸にプロットすると

ggplot(msleep, aes(brainwt, sleep_total)) +
  geom_point()

#こんな感じです。ちょっと左にデータが
#偏っていて見にくいので、対数をとる
#関数、log()を利用してあげて、

ggplot(msleep, aes(log(brainwt), sleep_total)) +
  geom_point()

#見やすくなりました。

#ここで、何を主に食べているかを表す変数、
#voreを利用して、点の形を設定するのであれば、
#aesの中でshapeを利用してあげて、

ggplot(msleep, aes(log(brainwt), sleep_total)) +
  geom_point(aes(shape=vore))

#こんな感じになります。
#さらに色をつけてあげると、

ggplot(msleep, aes(log(brainwt), sleep_total)) +
  geom_point(aes(shape=vore, color=vore))

#こんな感じです。

#以上、お疲れさまでした。これで色分けと形について
#説明は終了です。
#次の動画からは、軸のラベルについて
#解説していきます

## Lec: ggplot2でのグラフ作成基礎:ラベルの設定-----------------

# Slide:70-73

#スライドで解説した内容を実施しましょう
library(tidyverse)
ggplot(msleep, aes(log(brainwt), sleep_total)) +
  geom_point(aes(shape=vore, color=vore))

#このグラフに、タイトル、x軸、y軸を設定していきます
#スライドの通り、

ggplot(msleep, aes(log(brainwt), sleep_total)) +
  geom_point(aes(shape=vore, color=vore)) +
  labs(title = "動物の脳の重さと睡眠時間の関係",
       x = "対数変換後の脳の重さ[log(kg)]",
       y = "睡眠時間の長さ[時間]")

#簡単ですね?
#もちろん、変数も使えるので、
title_text <- "変数の中のタイトル"
x_lab      <- "変数内のラベルX"
y_lab      <- "変数内のラベルY"

base_graph <- ggplot(msleep, aes(log(brainwt), sleep_total)) +
  geom_point(aes(shape=vore, color=vore))

base_graph

#こんな感じの基本のグラフに対して、

label_graph <- base_graph +
  labs(title=title_text, x=x_lab,y=y_lab)
#labsでタイトル等をつけてあげて、

label_graph
#こういう風に作成することもできました。
#いかがでしょうか？
#ここはそれほど難しくないはずです。
#
#次は、凡例の設定について解説していきます。
#多分、ggplotでのグラフ作成で一番
#ややこしい部分かもしれません。


## Lec: ggplot2でのグラフ作成基礎:凡例の設定方法-----------------

#slide74-89

## Lec:ggplot2でのグラフ作成基礎:凡例の設定実践--------

#ここでは、凡例の内容の操作について解説していきます

library(tidyverse)

graph <- ggplot(diamonds) + geom_histogram(aes(x = price, fill = clarity))
graph

#まずは、スライドではでてきませんでしたが、
#凡例をけしてみましょう　
#guide = FALSEとすることで表示をなくすことが
#できます。

graph + scale_fill_discrete(guide = FALSE)

#guideは初期設定がTRUEで表示されるようになっているため
#特に指定しなければ消えないので安心してください。

#次にタイトルを変えてみましょう
#nameに変更したい文字列を与えてあげるだけ
#でOKなので、

graph
graph + scale_fill_discrete(name = "透明度")

#かわりましたね?

#次に表示される順番を変えてみましょう。
?diamonds

#一応、I1が最悪で、IFが最高の透明度
#らしいです。現状は、

summary(diamonds$clarity)
#と、Ord.factor

#最悪から最高までの順番でちゃんとならんでおります

str(diamonds$clarity)
#をみてみると、実はこの変数、これまで解説していない
#Ord.factorという、因子型に順番が設定された
#変数となっております。
#
#Legendの表示順は原則アルファベット順なのですが、
#順番を指定した因子型にすると、順番通りに
#並べてくれるので、便利です。
#ただ、現状ではとりあえず、そんなものがあるんだ
#なあくらいの認識でいてもらってよいかと思います。

graph

# グラフの描画でもこの順番に上からならんでいます。
# ここでは、最高から最悪まで表示されるように順番を
# 入れ替えてみましょう

new_order <- c("IF","VVS1","VVS2","VS1","VS2",
               "SI1","SI2","I1") 

#このnew_orderをscale_fill_discreteの
#breaks に与えてみます。

graph
graph + 
  scale_fill_discrete(breaks = new_order)

#こんな感じでIFを一番上にすることに成功しました
#色合いが実はOrderedFactorそのままの場合と、
#順番を分けた場合に変化しています。
#本コースでは、基本的なところをお伝えする
#方針なため、色を個別に変更するところまで
#は踏み込みませんのでその点、ご了解いただけます
#と幸いです。
#
#最後に、Legendに表示される内容にラベルを
#つけてみましょう。

#ダイヤモンドの透明度について知らないので、
#調べてみると、

#透明度とは、ダイヤモンドに含まれる微少な包有物
#I1:含まれる 
#SI2:わずかに含まれる
#SI1:わずかに含まれる
#VS2:ほんのわずかに含まれる
#VS1:ほんのわずかに含まれる
#VVS2:ごくごくわずかに含有
#VVS1:ごくごくわずかに含有
#IF:内部が無傷

#という説明になっているので、ラベルをつけます

levels(diamonds$clarity)
#で表示された順番に、
text_label_of_clarity <- c("含まれる",
                           "わずかにSI2","わずかにSI1",
                           "ほんのわずかにVS2","ほんのわずかにVS1",
                           "ごくごくわずかにVVS2","ごくごくわずかにVVS1",
                           "内部が無傷")

#という文字列ベクトルを作成してあげて、
graph
graph + scale_fill_discrete(labels = text_label_of_clarity)

#とすることで、表示名も変更できました!


#ここまで学んだ情報をまとめて記載すると、
ggplot(diamonds) + 
  geom_histogram(aes(x = price, fill = clarity)) +
  labs(title = "値段と含有物のヒストグラム", x = "値段", y = "件数") +
  scale_fill_discrete(name = "透明度", 
                      labels = text_label_of_clarity)

#こんなグラフがかけるようになりました！

#お疲れさまでした!
#次は演習問題を解いていきましょう。


## Lec:ggplot2でのグラフ作成基礎:凡例の設定演習------

#凡例の設定のところでご紹介した新しい関数は
#scale_color_discreteと、scale_fill_discreteの
#二つですが、中身の設定がすこしごちゃごちゃしていた
#と思いますので、ここで演習問題を解きながら
#身に着けていきましょう。 

# 
#利用するのはmsleepデータです、
#まず、

base_graph <- ggplot(msleep) +
  geom_point(aes(x=log(bodywt), y=log(brainwt), color=vore))

base_graph

#このbase_graphがあるとして、これのラベルと凡例
#を「キレイ」にしてみてください。
#(尚、x軸、y軸ともに、log関数を理容して対数に
#してあります。対数にしないと)
ggplot(msleep)+geom_point(aes(x=bodywt,y=brainwt))
#こんな感じで左下に「ぐしゃっ」となるためです。
#
#では、
base_graph
#のタイトルを　体重と脳の重さの関係
#　x軸のラベルを　体重[log(kg)]
#　y軸のラベルを　脳の重さ[log(kg)]
#　凡例のタイトルを　食性
#　凡例のラベルをそれぞれ
#　　carni 肉食
#　　herbi 草食
#　　insecti 虫食
#　　onmi 雑食
#　　NA その他
#　として、carni insecti hrebi omni NA
#　の順番に並び替えてみてください。
#　
#　それでは、動画を止めてどうぞ。
#　
#　
#　
#　
#　
#　
#　できましたか?

# タイトルとラベルをまず設定するのはlabs関数、
# でしたね?

base_graph +
  labs(title = "体重と脳の重さの関係",
       x = "体重[log(kg)]", y = "脳の重さ[log(kg)]")

#それで、凡例を設定するためには、ここで、
#scale_color_discreteか、scale_fill_discreteの
#どちらかに設定を行ってあげる必要がありますが
#どちらを利用するか、判断できましたでしょうか？
#
#今回の場合は、base_graphは、
#ggplot(msleep) +
# geom_point(aes(x=log(bodywt), y=log(brainwt), color=vore))

#color=voreと、colorを利用して凡例を描画
#しているため、次のようなスクリプトが正解になります

base_graph + 
  scale_color_discrete(
    name="食性"
  )

#それで、あとはラベルと並び順です。
#一応、NAが文字列のNAなのか欠損のNAなのかは
#確認したいので、

str(msleep$vore)
summary(msleep$vore)

levels(as.factor(msleep$vore))

#もともとのデータが文字列型で、
#本当に欠損しているみたいです。
#ggplotでは、文字列型は因子型と同様の扱い
#になってカテゴリー変数とみなされるため、

narabi <- c("carni","insecti","herbi","omni", NA)
hyouji <- c("肉食","虫食","草食","雑食","その他")

#ここでnarabiのNAは"NA"でなくて、NAであることに
#注意しておいてください。
NA
"NA"
#は明確に違います。NAは欠損を表すもので
str(NA) #ロジカル型
str("NA") #文字列型
#です。
#
#それで、作成した変数を利用して、

base_graph +
  scale_color_discrete(
    name = "食性",
    breaks = narabi,
    labels = hyouji
  )

#となります。
#いかがでしょうか？

#あともう1問やっておきましょう。

dat <- tibble(a=c(1,2,3),b=c(1,2,3),n=c("a","b","b"))

ggplot(dat)+geom_col(aes(x=a,y=b,fill=n))

#geom_colは初めてでてくるgeomですが、
#棒グラフを集計なしで作成する
#geomです。
#geom_barだと、x軸の指定をすると勝手に
#集計してくれていましたが、geom_colは
#y軸の値の指定も必要です。
#
#こんなグラフ、凡例のタイトルをエヌ、
#凡例の並びをa->bではなく、b->aにして、
#aはエー、bはビーというラベルを付けてみてください。
#
#
#
#
#
#
#
#
#
#
#
#できましたか？

ggplot(dat)+
  geom_col(aes(x=a,y=b,fill=n)) +
  scale_fill_discrete(
    name="エヌ",
    breaks=c("b","a"),
    labels=c("ビー","エー")
  )

#こんな感じで自分でデータを作って関数の動きを
#確認できるようになると、学習速度が上がることと、
#将来、関数を作成した時に意図した通りに
#動くかの確認をしたりするときに非常に役立つので
#すきをみて取り組んでみてください。
#
#それでは、次はggplotの基礎の最後、テーマの設定
#について解説していきます。

## Lec:ggplot2でのグラフ作成基礎:themaの解説------

#Slide 89-93

## Lec:ggplot2でのグラフ作成基礎:themaの実践-------

#それでは、ここでは事前設定されたテーマ
#をグラフに適応していきましょう。
#
#ここでは、msleepデータのグラフに対して
#操作をおこなっていきます。

library(tidyverse)
gg <- ggplot(msleep)+
  geom_point(aes(x=log(bodywt),y=sleep_total,color=vore))

gg
#まず。デフォルトの見た目はこんな感じです。
#「それなり」ですが、もっとよくできます。
#
#ggplot2にある、theme_xxxという関数群を
#今回作成したgg変数に足してあげて描画すると、

gg+theme_bw()
gg+theme_classic()
gg+theme_dark()
gg+theme_gray()
gg+theme_light()
gg+theme_linedraw()
gg+theme_minimal()

#こんな感じでグラフがかわります!
#いかがでしょうか?
#これらのtheme_xxxは、
?theme
#のアーギュメントの値をデフォルトで設定されている
#ものにして、グラフ全体の見た目を整えることことが
#できます。
#他に、このtheme関連の関数を提供することが
#目的のパッケージもあったりします。

#install.packages("ggthemes")

library(ggthemes)

gg + ggthemes::theme_base()
gg + ggthemes::theme_calc()
gg + ggthemes::theme_economist() #Economist(雑誌)とにたテーマ
gg + ggthemes::theme_economist_white()
gg + ggthemes::theme_excel() #説明分がひどいです・・・「絶対につかわないで」
gg + ggthemes::theme_few()
gg + ggthemes::theme_fivethirtyeight()
gg + ggthemes::theme_gdocs()
gg + ggthemes::theme_stata()
gg + ggthemes::theme_wsj() #Wall Street Journalとにたテーマ

#以上、駆け足でしたが、「ggplot2で基本的な
#グラフを描けるようになる」を目的に解説してきました。
#残りのこのセクションの動画、追加でもう少し
#ggplotを使いこなしたい人向けの解説になります。
#すこしややこしい話もあるので、現時点であまり興味
#がない人は飛ばしてもらってもよいと思います。
#
#さらにggplotについて学びたい方は、
#脱初心者のためのデータ可視化コースを
#別に用意してありますので、そちらを
#見ていただけると嬉しいです。
#
#ここまででも、ものすごい進歩です!
#是非、自分で自分を褒めてあげましょう。
#
#それでは次のセクションでお会いしましょう!

## Lec:補足：集計方法を指定して描画する～statオプション~-------

library(ggplot2)

dat <- tibble(
  age_group　= c("~20","21~40","41~60","61~80","81~100"),
  pop = c(13,20,32,55,20)
)

# こんな感じの、集計済みデータあるとしましょう。
# age_groupは集団の属する年齢、popは人数だとします
# それで、
dat

ggplot(dat) + geom_bar(aes(x = age_group))

#とすると、x軸のage_groupを集計して表示するため、
#それぞれの年齢は1件ずつとなり、
#y軸の値は集計された1件となります

#ここで、geom_barに集計をさせない方法を考えてみます。
#y軸の値を与えてあげて、それを描画する方法です。
#単純に、y軸の設定をしても
ggplot(dat) + 
  geom_bar(aes(x = age_group, y = pop))

# xかy、どちらかしか設定できませんとおこられますが、

ggplot(dat) + 
  geom_bar(aes(x = age_group, y = pop),
           stat="identity")
#と、stat_identityとすると、集計をせずに
#描画してくれます。
#これは、
ggplot(dat)+geom_col(aes(age_group,pop))
#geom_colとまったく同じ挙動なのであんまり役に立たないかも
#しれないですけどね。



## Lec:補足：theme!:凡例の位置を変える-----

# この動画では、themeを直接操作して凡例の
# 位置を変更していきます

library(tidyverse)

gg <- ggplot(msleep)+
  geom_point(aes(x=log(bodywt),y=sleep_total,color=vore))

gg

#凡例、デフォルトではグラフの右側に
#表示されていますが、

gg + theme(legend.position = "bottom")
gg + theme(legend.position = "right")
gg + theme(legend.position = "top")
gg + theme(legend.position = "left")

#とすることで、下、左、上に
#表示する場所を変更できます。
#また、要素が2個の数字を与えてあげると

gg + theme(legend.position = c(1,1))
gg + theme(legend.position = c(0.5,0.5))
gg + theme(legend.position = c(0,0))
gg + theme(legend.position = c(0.8,0.5))

#と、こんな感じで好きな位置に凡例を動かすこと
#が可能です。
#グラフの余ったスペースに凡例を入れ込むような
#ことも簡単にできるので、必要そうであれば
#試してみてください。
#
#尚、
gg + 
  theme(legend.position="left") + 
  theme_bw()

#等、theme_xxを後に足すと、せっかく足した
#設定が上書きされてしまうので、

gg + 
  theme_bw() +
  theme(legend.position="left")

#こんな感じで、themeは最後につけてあげる
#のがコツです。

## Lec:補足：X軸のテキストが重なる場合の解消法 --------------------------------------------

#グラフを作成していてよくある困りごとが
#x軸にカテゴリカル変数を入れた場合にその
#文字列が長すぎてしまう場合です。
#
#ちょっと極端ですが、
table <- tibble(
  item_name　= c("究極のマスクメロンアイスクリーム",
                "イチゴたっぷりショートケーキイタリア風",
                "和栗の贅沢ブラックモンブラン",
                "朝どれ卵のなめらかプリン",
                "マンゴーと南国フルーツのタルト",
                "フルーツをたっぷりつかったロールケーキ"),
  uriage_kosu = c(39,42,73,88,93,132)
)

gg <- ggplot(table) + 
  geom_col(aes(item_name, uriage_kosu), stat="identity")

gg
#このようにX軸が重なってしまったというとき
#の回避策をここで解説しておきます。
#なお、ここでは、x軸の表示の話であるため
#scale_x_discrete
#で設定をいじっていきます。
#
#＊scale_color_discreteでlegendの設定
#をいじったのと同じようなイメージです。

#その1:x軸の表示を回転させる

gg +
  scale_x_discrete(guide = guide_axis(angle=45))

#できました！
#
#ここでは、scale_x_discreteの
#guideアーギュメントに、guide_axis関数の結果を
#わたしてあげることでグラフの表示を操作しています

guide_axis(angle=45)

#また、実はggplot2が難しいといわれる理由
#の一つに、同じ結果を複数の書き方で
#実現できてしまうところがあります。
#
#scale_x_discreteでなくて、

gg +
　theme(axis.text.x = element_text(angle=45,hjust=1))

#themeでaxis.text.xの設定をいじっても同じ
#効果になります。

#ただし、theme_classicなどを設定すると
#上書きされるので、
gg +
  theme(axis.text.x = element_text(angle=45, hjust = 1)) +
  theme_classic()

#注意が必要です。

#hjustやtheme_xxの上書き等気にしないといけない
#ことが多いので、scale_x_discreteの
#guideをいじるほうが良いと思います。

#その2:x軸の表示をずらす
#こちらの方法もguideで設定できます。
gg +
  scale_x_discrete(guide = guide_axis(n.dodge = 3))

gg + 
  scale_x_discrete(guide = guide_axis(n.dodge = 4))

#こんな感じで、guide_axisのn.dodgeアーギュメント
#に数字を与えてあげることで、テキストをずらして
#表示することが可能です。
#
#このグラフの問題としては
#グラフ自体は拡大すると文字が全部入りますが、
#小さいグラフで文字がはみ出てしまっています。
#何とかするために、余白を増やしてあげましょう
#グラフ全体の余白はthemeでplot.marginに

margin(1,2,3,4,"pt")

#関数の結果を与えてあげることで実現できます

gg + 
  scale_x_discrete(guide = guide_axis(n.dodge = 6)) +
  theme(plot.margin = margin(10,40,10,20,"pt"))

#いかがでしょうか?
