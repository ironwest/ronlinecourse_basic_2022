## Lec: セクションの導入--------------

# Slide:1-5

## Lec: Markdownとは?-----------------

# Slide:6-8

## Lec: Rmarkdownとは?---------------------

# slide:9-12

## Lec:RmarkdownをKnitしてみる---------------

# slide:13
# example2.Rmd

#File->New File->RMarkdownで作成する手順を示す。

#この作成されたファイルに
#example2.Rmdの内容を入力。Ctrl＋Alt＋Iで
#コードチャンクを入力できることもここで解説

## Lec:YAMLの解説-------------------

# slide:14-23
# temp.Rmd
# temp.Html

## Lec:チャンクオプションの解説----------

# slide:24

# ここでは、チャンクオプションと呼ばれる、
# Rのスクリプトの実行結果に色々と
# 影響を及ぼす設定について解説していきます
# 
# example3.Rmdへ
# 

## Lec:チャンクオプションの解説(全体の設定)-----

# slide:25

# 1つ前の動画で、一個のコードチャンクの設定方法を解説しました
# ただ、チャンク毎に設定するのが面倒で、全体に
# 設定したい場合もよくあるので、ここではその方法
# を解説しておきます。
# 
# example3-2.Rmdへ

## Lec:Wordへの出力--------------------

# slide:26

# ここまでは、RmdファイルをHTMLファイルへ出力してきました。
# ここからは、RmdファイルをWordファイルとPowerpointファイル
# へ出力する方法をご説明いたします。
# 
# example4.Rmdへ

## Lec:Wordへの出力2--------------

# slide:27

#1つ前の動画で、無事にWordファイルへ出力できました。
#ただ、この見た目が余り気に食わない場合は、どうすれば
#よいでしょうか?

#普段利用しているwordのスタイル(見た目)がある等の
#場合、そのスタイルでの出力ができた方がよいですよね?

#実は、テンプレートファイルを用意すれば、非常に簡単に
#見た目をいじることができます。

#tempate.docxを開いて見た目を編集してみましょう。

#その後、example5.Rmdを開いてみてください。

#example5.Rmd

## Lec:Powerpointへの出力----------------

# slide28

# それでは、ここからはPowerpointファイルへの
# 出力について実施していきます。
# 
# これも、実はYAMLをいじるだけで良いのですが
# そのYAMLの内容、あまり沢山覚えるのも大変
# なので、
# RStudioに作成してもらいましょう。
# 
# File -> New File -> RMarkdown ->
#  Presentation -> PowerPoint
# 
# で新しくファイルを作成してみてください。
# それで表示されたファイルのYAMLを見ていただくと、
# 
# output: powerpoint_presentation
# 
# となっており、この記載があると、
# Knitボタンのところにスライドで出力
# するオプションが色々と表示されている
# はずです。
# 
# HTMLでプレゼンできるフォーマットもあったり
# しますが、本コースではPowerpoint
# に絞って話を進めます。
# 
# とりあえず、RStudioが作成してくれたファイルを
# 適当な名前で保存して、Knitしてみましょう
# 
# Powerpointファイルが生成されましたね?
# 
# それでは、Wordを作成するときに利用したRmd
# ファイルを利用して同じ内容でPowerPointファイル
# を作成してみましょう。
# 
# example6.Rmdへ
 
## Lec:Powerpointへの出力2----------------

# Slide29

# それでは、ここでは、wordの時と同じように、
# 見た目やデザインを変えてみましょう
#
# template.pptxへ
# example7.Rmd

#以上がRmarkdownの使い方の基本的な解説でした。次の動画
#では続いて、Excelにデータを出力する方法について解説していきます。
#


## Lec:Openxlsx:Excelへの出力----------------

# Lec30

#ここからは、エクセルへの
#出力について解説していきます。
#
#ここで利用するのはopenxlsxというパッケージ
#です。
#
#早速、installしてみましょう

# install.packages("openxlsx")

# この、openxlsx、これまでの関数で
# データを加工していくやり方と少し
# 使い方が違って戸惑うかもしれませんが、
# それほどむずかしくありません。
#　ここでは、

library(tidverse)
library(openxlsx)

dat <- tibble(
  col1 = letters[1:5],
  col2 = 1:5 
)

dat

# というデータを書き込んでみましょう。

#まず、エクセルブック（ファイル)を作ります
wb <- openxlsx::createWorkbook()
#この時点では、Rの中にだけしか存在していない
#オブジェクトであることに注意が必要です。
#
#それで、ここから少しopenxlsxがこれまでと
#違うのはいちいち wb <- kansu(wb, ...)
#という様に入力しないでもよいというところ
#です。

#newというシートを足してあげて
openxlsx::addWorksheet(wb,"new")

#そのシートにデータ、datを書き込んで
openxlsx::writeData(wb,"new",dat)

#ファイルをout1.xlsxという名前で保存する
openxlsx::saveWorkbook(wb,"out1.xlsx",overwrite = TRUE)

#という処理が、こんな感じで実行できます。
#フィルを開いてみましょう!
#
#いかがでしょうか?
#無事に書き込めていますね?

#このopenxlsxパッケージ、セルの色を変えたり、
#セルを結合したり、罫線を引いたりというものを
#全てRの関数で実行することができます。
#
#ここらへん、エクセルVBA（マクロ)を触った
#ことがある人にとってはなじみ深い操作かも
#しれませんね?
#
#本コースではOpenxlsxの詳しい使い方
#には踏み込みませんが、一応、wordや
#powerpointでやったように、すでにある
#ファイルにデータを書き込む形で、
#あらかじめデザインしたものにデータ
#を書き込む処理をご紹介いたします。
#

## Lec:Openxlsx:Excelへの出力2----------------

# Lec31

#それでは、もととなるエクセルファイルは、
#template.xlsxという名前のファイルでです。

#このエクセルファイルの
#
#B3:H7
#B10:H14
#B17:H21
#
#この範囲にデータを書き込んでみましょう。

dat1 <- tibble(
  a=rnorm(4),
  b=rnorm(4),
  c=rnorm(4),
  d=rnorm(4),
  e=rnorm(4),
  f=rnorm(4),
  g=rnorm(4)
)

dat2 <- tibble(
  a=rgamma(4,1,1),
  b=rgamma(4,1,1),
  c=rgamma(4,1,1),
  d=rgamma(4,1,1),
  e=rgamma(4,1,1),
  f=rgamma(4,1,1),
  g=rgamma(4,1,1)
)

dat3 <- tibble(
  a=rpois(4,4),
  b=rpois(4,4),
  c=rpois(4,4),
  d=rpois(4,4),
  e=rpois(4,4),
  f=rpois(4,4),
  g=rpois(4,4)
)

dat1
dat2
dat3

#こんなデータとなります。

#それで、まずは、tempate.xlsxをRに読み込みます
wb <- openxlsx::loadWorkbook("template.xlsx")

#dat1を読み込んだwbのB3:H7の範囲に書き込みます
openxlsx::writeData(
  wb = wb,
  sheet = "res",
  x = dat1,
  startCol = 2,
  startRow = 3
)

#dat2を読み込んだwbのB10:H14の範囲に書き込みます
openxlsx::writeData(
  wb = wb,
  sheet = "res",
  x = dat1,
  startCol =  2,
  startRow = 10
)

#dat3を読み込んだwbのB17:H21の範囲に書き込みます
openxlsx::writeData(
  wb = wb,
  sheet = "res",
  x = dat3,
  startCol =  2,
  startRow = 17
)

#保存します
openxlsx::saveWorkbook(wb,"out2.xlsx",overwrite=TRUE)

#いかがでしょうか?template.xlsxの内容に
#データを付け足すことができていますね?
#
#この方法を利用すれば、
#エクセルファイルのデザイン
#をすべてプログラム的に書くようなことを
#しなくてすむので効率的です。
#
#ただし、この方法、元となるエクセルファイル私大では
#うまく読み込めないこともあるため、できればラッキーくらい
#の気持ちでよいかもしれません。
#（実務で利用する場合は、個人的には、RからPythonの
#エクセルファイルを加工するライブラリを呼び出して、
#それで
#　　データ加工：R
#　　エクセル操作：Python
#　　という形で対応することが多いです。

## Lec:Openxlsx:Excelへの出力3---------------------

# slide32

#おまけです。
#実は、openxlsxには、データをエクセルファイルに簡単に書き出せる
#関数が用意されています。

library(tidyverse)
dat <- tibble(a = 1:10, b = 11:20)

openxlsx::write.xlsx(dat,"easy.xlsx")

#easy.xlsxという名前でファイルが作成されて、datの内容
#が含まれていますね？
#
#
#以上、駆け足でしたがレポートの作成方法についてでした。
#
#

# ここまで学んだ知識を駆使して、本コースの最終課題として、
# 実際の状況を想定して、レポートを作成する行程を一緒に
# やっていきましょう。

## Lec:Rmarkdownでレポートを作成してみる―状況設定-------

#slide33

# ここからは本コースの締めくくりとして、単純集計とグラフを利用した
# レポートの作成を通して、Rを実際に利用する場面を想定した
# 課題をやっていきましょう。
# 
# 「課題」としていますが、ここまで解説していない概念や関数もたくさん登場します。
# 
#  そのため、自分でとくのではなく、その状況に自分がおかれたらと
#  想像しつつ動画と一緒に内容を追っていただいて、
#  解き方の解説を見たうえで、次のRの勉強の指針としていただくことを
#  想定した問題となっています。
#  
#  だいぶ高度なことをしているように見えるかもしれませんが、
#  少しだけ勉強していただければ、Rが統計解析だけでなく、
#  色々な場面で便利に利用できるプログラミング言語であることを
#  理解いただけると思います。
#  
#  それでは、はじめていきましょう。
# 
# 状況設定
# 　あなたは、ある会社に務めている産業看護職です。
# 　体重と血圧をターゲットにした健康施策を会社で実行するに
# 　あたり、どの職場を重点的に対策をしたらよいかを調べたい
# 　と思っています。
# 　
# 　血圧と体重を含む5年間のデータを利用して、
# 　　会社全体のレポート
# 　　職場別のレポート
# 　　個人別のレポート
# 　を作成するようなことをやりたいと思っています。
# 　
# 課題1:
# 　kadai/dataフォルダに含まれる、data.csvファイルにはある
# 　会社の健康診断の（架空の）データが含まれています。
# 　この架空データ、列が６個あり、
# 　
# 　wpid: 職場ID
# 　id  :個人のID
# 　yr  :健康診断の年度
# 　bmi :BMI
# 　sbp :収縮期血圧
# 　dbp :拡張期血圧
# 　
# 　です。ここで、個人を特定するにはwpidとidを
# 　組み合わせて行う形なっています。
# 　なので、id=1の人はwpid毎に一人ずついるので
# 　注意してください。
# 　
# 　このデータを利用して、Rmrkdownを書いて、
# 　会社全体のレポートを上司に向けて作成してみてください。
# 　レポートの内容は、上司はパワーポイントでの発表を好むので、
# 　
# 　スライド1：タイトル
# 　スライド2：全体を集計した表
# 　スライド3~：職場別に集計した表

#
#　　としましょう。どのような集計方法と
#　　するかは、皆さんにお任せします。
#　　なお、会社の標準的なプレゼン資料のテンプレートは、
#　　kadai/bunseki_co_template.pptxの内容であるので、
#　　それを反映してください。
#
#課題2：
#　　次に、職場別に集計して上司にプレゼンした結果、
#　　ここの職場の担当者にも結果を送ってほしいと上司から
#　　いわれました。会社は伝統的にデータのやりとりは
#　　エクセルファイルで行われています。
#　　
#　　課題１の集計結果を、それなりに見栄えのする表を作って
#　　各職場の担当者に送信するためのエクセルファイルを
#　　職場の数だけ作成してみてください。
#　　
#　　
#課題3：
#　　上司から、BMIが30以上の人、BMIが16未満の人、
#　　あるいは血圧が160/100どちらかが超えている人
#　　を抽出して、個々のグラフを作成して、それを利用して
#　　産業看護職として健康相談をおこなうように指示がありました。
#　　
#　　これまで、エクセルで条件に当てはまる人を抽出して、
#　　グラフと表を作成して、Wordファイルに貼り付けたうえで、
#　　コメントを書いていました。
#　　
#　　Wordファイルを作成するところまでをRでやってみましょう。
#　　今回は、面談時に提示するだけなので、特に凝ったレイアウトは
#　　必要ありません。


#架空データの作成用スクリプト
{
  
  library(tidyverse)
  
  set.seed(12345)
  sampledata <- tibble(
    wpid = 1:5,
    hiddenp = c(-5,0,5,3,-2),
    n = c(100,80,200,40,400)
  ) %>% 
    mutate(
      data = map2(hiddenp,n,~{
        param <- .x
        n     <- .y 
        
        tibble(id = 1:n) %>%
          mutate(hiddenip = rnorm(n,param,5)) %>% 
          mutate(values = map(hiddenip,~{
            tibble(
              yr = 2000:2002,
              bmi = rnorm(3,rnorm(1,23+hiddenip*0.1 )),
              sbp = rnorm(3,rnorm(1,5*hiddenip+135)),
              dbp = rnorm(3,rnorm(1,5*hiddenip+77 ))
            )
          }))
      })
    )
  
  sampledata2 <- sampledata  %>% 
    select(wpid,data) %>% 
    unnest(data) %>% 
    select(!hiddenip) %>% 
    unnest(values)
  
  summary(sampledata2)
  
  write_csv(sampledata2,"kadai/data/data.csv")
}


## Lec:Rmarkdownでレポートを作成してみる―課題1-------

# 課題1:
# 　kadai/dataフォルダに含まれる、data.csvファイルにはある
# 　会社の健康診断の（架空の）データが含まれています。

# 　このデータを利用して、Rmrkdownを書いて、
# 　会社全体のレポートを上司に向けて作成してみてください。
# 　レポートの内容は、上司はパワーポイントでの発表を好むので、
# 　
# 　スライド1：タイトル
# 　スライド2：全体を集計した表
# 　スライド3~：職場別に集計した表
# 　
#　　としましょう。どのような集計方法と
#　　するかは、皆さんにお任せします。
#　　なお、会社の標準的なプレゼン資料のテンプレートは、
#　　kadai/bunseki_co_template.pptxの内容であるので、
#　　それを反映してください。

#それでははじめていきましょう。
#まずは、実際にRMarkdownを書く前に
#どんな表とグラフを表示するか、をここで考えておきます。

library(tidyverse)

dat <- read_csv("kadai/data/data.csv")

#全体を集計した表:
# tidyverseだけを利用するなら、
hyou1tidyv <- dat %>% 
  group_by(yr) %>% 
  summarise(
    across(c(bmi,sbp,dbp),
           .fn = list(mn = ~{mean(.)},
                      q25 = ~{quantile(.,0.25)},
                      q75 = ~{quantile(.,0.75)}),
           .names = "{.col}_{.fn}")
  ) %>% 
  mutate(across(!yr, ~{signif(.,3)})) %>% 
  mutate(
    bmi_res = str_glue("{bmi_mn}({bmi_q25}-{bmi_q75})"),
    sbp_res = str_glue("{sbp_mn}({sbp_q25}-{sbp_q75})"),
    dbp_res = str_glue("{dbp_mn}({dbp_q25}-{dbp_q75})")
  ) %>% 
  select(`年度`=yr,
         `BMI` = bmi_res,
         `収縮期血圧` = sbp_res,
         `拡張期血圧` = dbp_res)

#こんな感じで表を作成してあげます。
#across等を駆使して短めに書いてはいますが、ちょっと面倒です
#ここで利用している、
#　signifはという有効数字に丸める関数です。
#　str_glueは"{列名}"とすると、その部分を置き換えた文字に
#　　置き換えてくれる便利な関数です。
#
#ちょっと難しいかもしれません
#
#ただ、とりあえず、このような形の表を作成できれば、
#knitr::kableという関数に与えてあげると、自動的に
#markdown形式に変換してくれます。

hyou1tidyv

knitr::kable(hyou1tidyv)  

#これを利用してもよいですし、

#gtsummaryというパッケージを利用するともっと簡単に集計表
#を作成できて、

tbl <- gtsummary::tbl_summary(dat,by="yr",include = c("bmi","sbp","dbp"))
tbl
#こんな感じです。英語表記なので、日本語に直す手間は少し
#かかりますが、こちらの方が、処理の内容としては
#だいぶ楽だと思います。

library(gtsummary)
tbl2 <- tbl_summary(
  data = dat,
  by="yr",
  include = c("bmi","sbp","dbp"),
  label = list(bmi ~ "BMI", 
               sbp ~ "収縮期血圧",
               dbp ~ "拡張期血圧") 
) %>% 
  modify_header(list(label~"**検査値**")) %>%  
  　　　# 検査値を足しています
  
  modify_spanning_header( #この関数で「年度」を足しています
    list(
      stat_1 ~ "**年度**",
      stat_2 ~ "**年度**",
      stat_3 ~ "**年度**"
    )
  ) %>% 
  
  modify_footnote( # この関数でフットノートを日本語にしています
    list(
      stat_1 ~ "中央値(IQR)",
      stat_2 ~ "中央値(IQR)",
      stat_3 ~ "中央値(IQR)"
    )
  )

tbl2

# modify~という関数で設定を色々変えています。
# stat_1など、表の列名をしらべるには、

gtsummary::show_header_names(tbl)

#としてあげます。gtsummaryの詳しい使い方は本コースの対象範囲から
#はずれるので、ここでは上のようなパッケージや関数を使うと
#表が作れるんだというくらいの認識でよいと思います。

#今回は、この表を利用しましょう。
#尚、職場別に集計した結果は、このgtsummary::tbl_summaryに与える
#データをfilterを利用して職場単位に絞り込めばOKです。なので、

dat %>% count(wpid)

#このように、wpidが１から５まで、５つあるので、
#５回、処理を繰り返す必要があります。

dat %>% 
  filter(wpid==1) %>% 
tbl_summary(
  data = .,
  by="yr",
  include = c("bmi","sbp","dbp"),
  label = list(bmi ~ "BMI", 
               sbp ~ "収縮期血圧",
               dbp ~ "拡張期血圧") 
) %>% 
  modify_header(list(label~"**検査値**")) %>%  
  # 検査値を足しています
  
  modify_spanning_header( #この関数で「年度」を足しています
    list(
      stat_1 ~ "**年度**",
      stat_2 ~ "**年度**",
      stat_3 ~ "**年度**"
    )
  ) %>% 
  
  modify_footnote( # この関数でフットノートを日本語にしています
    list(
      stat_1 ~ "中央値(IQR)",
      stat_2 ~ "中央値(IQR)",
      stat_3 ~ "中央値(IQR)"
    )
  )

# ...
# さすがに面倒なので、関数化しておきましょう。

make_hyou <- function(.data){
  .data %>% 
    tbl_summary(
      data = .,
      by="yr",
      include = c("bmi","sbp","dbp"),
      label = list(bmi ~ "BMI", 
                   sbp ~ "収縮期血圧",
                   dbp ~ "拡張期血圧") 
    ) %>% 
    modify_header(list(label~"**検査値**")) %>%  
    # 検査値を足しています
    
    modify_spanning_header( #この関数で「年度」を足しています
      list(
        stat_1 ~ "**年度**",
        stat_2 ~ "**年度**",
        stat_3 ~ "**年度**"
      )
    ) %>% 
    
    modify_footnote( # この関数でフットノートを日本語にしています
      list(
        stat_1 ~ "中央値(IQR)",
        stat_2 ~ "中央値(IQR)",
        stat_3 ~ "中央値(IQR)"
      )
    )
}

#.data を与えてあげて、
#表ができあがります。

dat %>% filter(wpid==2) %>% make_hyou()

#この関数を用いて、kadai/kadai1_1.Rmd
#でレポートが出力できるか見ていきましょう。


## Lec:Rmarkdownでレポートを作成してみる―課題2-------

#課題2：
#　　次に、職場別に集計して上司にプレゼンした結果、
#　　ここの職場の担当者にも結果を送ってほしいと上司から
#　　いわれました。会社は伝統的にデータのやりとりは
#　　エクセルファイルで行われています。
#　　
#　　課題１の集計結果を、それなりに見栄えのする表を作って
#　　各職場の担当者に送信するためのエクセルファイルを
#　　職場の数だけ作成してみてください。
#　　

#この課題、xlsxに、gtsummary::tbl_summaryの結果を入れることが
#できれば解決します。tbl_summaryの結果を取り出して、表に入れられるように加工
#します。

tbody <- tbl2$table_body
tby   <- tbl2$df_by

View(tbody)
View(tby)

#tbodyは、

tbody2 <- tbody %>% 
  select(label, starts_with("stat_"))

tbody2
#を、そのまま入れてあげるとよさそうです。
#後は、列名を何とかしてあげたいですが結果で、人数行を
#作りつつ名前を置き換えるとすると、

ninzu <- tby$n %>% as.character()
nendo <- tby$by_chr

writeall <- tbody2 %>% 
  add_row(tibble(label = "人数",
                 stat_1 = ninzu[1],
                 stat_2 = ninzu[2],
                 stat_3 = ninzu[3]), .before = 1) %>% 
  setNames(c(" ", nendo))

#こんな処理をすることで、表ができあがりました。
#ここで、これまで紹介していない関数としてadd_rowがあります。
#これは、tibbleに対して、好きな内容の行を追加するという関数で、
#位置も指定可能です。
#
#あと、setNamesで名前を変換してあげると出来上がりです。
#
#繰り返しですが、この課題、「Rでこんなこともできる」という
#ことを例示するためのものなので、この回答が思いつかなくても
#このコースを１度みただけの方であれば問題ないと思います。
#気楽に見てください。

# wpid1-5も関数を利用して作成しておきます

make_table_for_excel <- function(gttbl){
  tbody <- gttbl$table_body
  tby   <- gttbl$df_by
  
  tbody2 <- tbody %>% 
    select(label, starts_with("stat_"))
  
  ninzu <- tby$n %>% as.character()
  nendo <- tby$by_chr
  
  res <- tbody2 %>% 
    add_row(tibble(label = "人数",
                   stat_1 = ninzu[1],
                   stat_2 = ninzu[2],
                   stat_3 = ninzu[3]), .before = 1) %>% 
    setNames(c(" ", nendo))
  
  return(res)
}

tblall <- dat %>% make_hyou() %>% make_table_for_excel()
tblp1 <- dat %>% filter(wpid==1) %>% make_hyou() %>% make_table_for_excel()
tblp2 <- dat %>% filter(wpid==2) %>% make_hyou() %>% make_table_for_excel()
tblp3 <- dat %>% filter(wpid==3) %>% make_hyou() %>% make_table_for_excel()
tblp4 <- dat %>% filter(wpid==4) %>% make_hyou() %>% make_table_for_excel()
tblp5 <- dat %>% filter(wpid==5) %>% make_hyou() %>% make_table_for_excel()

#この結果を、次にxlsxファイルに書き込んでみましょう。
#ここではopenxlsxを利用します。


#wpid1へのエクセルファイル

style <- openxlsx::createStyle(
  border = c("top", "bottom", "left", "right")
)

wb <- openxlsx::createWorkbook()
openxlsx::addWorksheet(wb,"wpid1")
openxlsx::writeData(wb,sheet="wpid1",x="全体" ,startCol=1,startRow=1)
openxlsx::writeData(wb,sheet="wpid1",x=tblall ,startCol=2,startRow=2)
openxlsx::writeData(wb,sheet="wpid1",x="WPID1",startCol=1,startRow=7)
openxlsx::writeData(wb,sheet="wpid1",x=tblp1  ,startCol=2,startRow=8)
openxlsx::addStyle(wb,"wpid1",rows=c(2:6),cols=c(2:5), style=style, gridExpand = TRUE)
openxlsx::addStyle(wb,"wpid1",rows=c(8:12),cols=c(2:5), style=style, gridExpand = TRUE)
openxlsx::setColWidths(wb,"wpid1",cols=c(2:5),widths="auto")
openxlsx::saveWorkbook(wb,"kadai/forwpid1.xlsx",overwrite = TRUE)

#うまくいきましたね？
#あとはこれを関数化しましょう。

make_excel_file <- function(excel_data, wpid=1){
  style <- openxlsx::createStyle(
    border = c("top", "bottom", "left", "right")
  )
  
  wptext <- str_c("wpid",wpid)
  
  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb,wptext)
  openxlsx::writeData(wb,sheet=wptext,x="全体" ,startCol=1,startRow=1)
  openxlsx::writeData(wb,sheet=wptext,x=tblall ,startCol=2,startRow=2)
  openxlsx::writeData(wb,sheet=wptext,x=wptext,startCol=1,startRow=7)
  openxlsx::writeData(wb,sheet=wptext,x=tblp1  ,startCol=2,startRow=8)
  openxlsx::addStyle(wb,wptext,rows=c(2:6),cols=c(2:5), style=style, gridExpand = TRUE)
  openxlsx::addStyle(wb,wptext,rows=c(8:12),cols=c(2:5), style=style, gridExpand = TRUE)
  openxlsx::setColWidths(wb,wptext,cols=c(2:5),widths="auto")
  openxlsx::saveWorkbook(wb, str_glue("kadai/for{wptext}.xlsx"),overwrite = TRUE)
}

#この関数を利用して、エクセルファイルを事業場毎（wpid毎）に、作成します。

dat %>% filter(wpid==1) %>% make_hyou() %>% make_table_for_excel() %>% make_excel_file(wpid=1)
dat %>% filter(wpid==2) %>% make_hyou() %>% make_table_for_excel() %>% make_excel_file(wpid=2)
dat %>% filter(wpid==3) %>% make_hyou() %>% make_table_for_excel() %>% make_excel_file(wpid=3)
dat %>% filter(wpid==4) %>% make_hyou() %>% make_table_for_excel() %>% make_excel_file(wpid=4)
dat %>% filter(wpid==5) %>% make_hyou() %>% make_table_for_excel() %>% make_excel_file(wpid=5)

#できましたね？今回、作成するファイルは５こですが、これが２０個とか１００個とか
#になると、R（プログラム）を介してファイル作成するメリットが感じられるようになるはずです。
#


## Lec:Rmarkdownでレポートを作成してみる―課題3-------

#課題3：
#　　上司から、BMIが30以上の人、BMIが16未満の人、
#　　あるいは血圧が160/100どちらかが超えている人
#　　を抽出して、個々のグラフを作成して、それを利用して
#　　産業看護職として健康相談をおこなうように指示がありました。
#　　
#　　これまで、エクセルで条件に当てはまる人を抽出して、
#　　グラフと表を作成して、Wordファイルに貼り付けたうえで、
#　　コメントを書いていました。
#　　
#　　Wordファイルを作成するところまでをRでやってみましょう。
#　　今回は、面談時に提示するだけなので、特に凝ったレイアウトは
#　　必要ありません。

#最後の課題です。
#まずは、条件に適合する人を抽出しましょう。

dat <- read_csv("kadai/data/data.csv")

filtdat <- dat %>%   
  filter(bmi >= 30 | bmi < 16 | sbp >= 160 | dbp >= 100) 

#35行が該当しました。（注：このデータはランダムに作成した架空のデータです。）
#対象者、複数回該当しているケースもあるので、distinctで重複を消しておきましょう。

filtdat %>% 
  distinct(wpid, id)
#20名分、つまり、２０個のWordファイルの作成が必要という形です。
#一人分のWordファイルに出力するグラフと表を作成してみます。

adat <- dat %>% 
  filter(wpid==4 & id == 1) %>% 
  mutate(yr = as.factor(yr))

ggplot(adat) + 
  geom_line(aes(x = yr, y = bmi, group=1)) +
  geom_point(aes(x = yr, y = bmi)) +
  theme_classic() +
  labs(x = "年度", y = "BMI")

#geomを重ねる話、本コースでは行っていませんが、
#このように重ねることも可能です（詳しくは中級者向けのグラフ描画コースで解説しています）
#他にも、
adat %>% 
  pivot_longer(c(sbp,dbp)) %>% 
  ggplot(aes(x = yr, y = value, shape=name, group=name)) +
  geom_point() +
  geom_line() +
  geom_hline(yintercept = c(80,120), linetype="dotted", color="black") +
  geom_hline(yintercept = c(90,140), linetype="dotted", color="orange") +
  geom_hline(yintercept = c(100,160), linetype="dotted", color="red") +
  scale_shape_discrete(name="血圧")+
  labs(x = "年度", y = "値", title = "血圧の推移") +
  theme_classic()

#こんな感じのグラフを作成することもできます。
#今回は、この２種類のグラフと次の表

adat %>% 
  select(yr,bmi,sbp,dbp) %>% 
  mutate(across(c(bmi,sbp,dbp),~{format(signif(.,3))})) %>% 
  rename(`年度` = yr, `BMI` = bmi, `収縮期血圧` = sbp, `拡張期血圧` = dbp)

#を含んだWordファイルを全員分作ることとします。
#ここで20名分のWordファイルを作るのに、Rmdファイルは1つで十分です。
#パラメーターレポートという、Rmarkdownの内容を簡単に置き換えられる仕組み
#を使って、20名分のレポートを作成してみましょう。
#
#まず、kadai3.Rmdを開いて中身を確認してみてください。
#
#knitした結果がwordファイルになっていますね？
#このkadai3.Rmdをパラメーターレポートにしてあげます。
#
#kadai3param.Rmdを開いてみてください。



#kadai3param.Rmdレポートを外から設定を変更して実行してみましょう。

rmarkdown::render(input       = "kadai/kadai3param.Rmd", 
                  output_dir  = "kadai/kojinreport",
                  params      = list(targetwpid = 1, targetid = 1),
                  output_file = "test.docx")

#どうでしょう？うまく実行できましたね？
#後は、これを繰り返し処理するスクリプトを書いて実行すると、うまくいきます。
#繰り返し処理については、このコースでは解説していませんでしたが、ここで
#簡単に解説しておきます。
#
#繰り返し処理は、forループというものを利用します。

for(i in 1:10){
  print(i)
}

# 最初はちょっとややこしいかもしれませんが、このようにforで始まる
# 構文で、{}の中身に繰り返したい処理を書いてあげることで、ジョジョに数字
# を変えながら{}の中身を実行することができます。
# 
# 今回、


dat <- read_csv("kadai/data/data.csv")

filtdat <- dat %>%   
  filter(bmi >= 30 | bmi < 16 | sbp >= 160 | dbp >= 100) 

filtdat <- filtdat %>% 
  distinct(wpid, id)

#このfiltdatの１行１行の組み合わせでwordファイルを作りたいので、
#そうなるようにforループを作成してみましょう。

for(i in 1:nrow(filtdat)){
  tgtwpid <- filtdat$wpid[i]
  tgtid   <- filtdat$id[i]
  
  print(str_c("wpid:",tgtwpid, "/", "id:",tgtid))
}

# tgtwpidとtgtidという変数にそれぞれ、i行目の値が含まれていますね？
# これを利用して、先ほどのrmarkdown::renderを実行してあげましょう。

for(i in 1:nrow(filtdat)){
  tgtwpid <- filtdat$wpid[i]
  tgtid   <- filtdat$id[i]
  
  filename <- str_c("repoort_",tgtwpid,"_",tgtid,".docx")
  
  print(str_c("wpid:",tgtwpid, "/", "id:",tgtid))
  rmarkdown::render(input       = "kadai/kadai3param.Rmd", 
                    output_dir  = "kadai/kojinreport",
                    params      = list(targetwpid = tgtwpid, targetid = tgtid),
                    output_file = filename)
}


#このforループでkadai/kojineportの中には、20個のwordファイルができています。

list.files("kadai/kojinreport/",pattern="docx")

#それぞれの中身は、ファイル名にあるように、各々のidのデータが反映された
#グラフと表になっているはずです。
#
#Lec：終わりに――――――――――――――――――――――

#いかがでしたでしょうか？
#最後の課題の回答、少し難しかったかも知れませんが、
#このコースを最後まで通して見ていただいた方であれば、もう少し勉強すれば、
#ここでお示しした内容でのレポート作成、かならずたどり着ける到達点の一つ
#だと思います。
#
#ぜひ、この先も学び続けていただき、皆さんの業務や学業でRを活用していって
#いただければ本当に嬉しく思います。
#
#本コースは私が最初に作成したR言語の入門コースを、
#最初のコースでカバーできなかった部分を取り込み、さらに、次のステップに
#進む方が増えることを願って作成したものです。
#
#最初のコースに含んでいた、統計分析の内容は、このコースからは意図的に外しました
#
#それは、コースが長くなってしまうこともあるのですが、R言語を学び始める上で、
#統計の難しさとR言語の難しさを混同してしまうケースを何件か経験したからです。
#
#そのため、このコースは意図的にRで分析に到達する前と、分析が終わった後の話を
#中心に行い、統計分析の話はしていません。
#
#統計分析はぜひ、このコースの後かあるいは平行して学んでいっていただくと、
#R言語の幅広さや楽しさを理解していただけるのではないかと期待しています。
#
#長いコースにお付き合いいただきありがとうございました。
#当初の予定より２倍以上に収録時間が伸びてしまいました。
#最後までみていただき、本当にありがとうございます。
#
#このコースが皆さんのRライフを少しでもよいものにできればと願っています。
#それでは、またどこかで、ご縁があればお会いしましょう！
